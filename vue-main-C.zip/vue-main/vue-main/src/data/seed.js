// 種子資料（可預覽），首次載入會寫入 localStorage
export const seedData = {
  meta: { version: 1 },
  stores: [
    {
      id: "S001",
      name: "某某餐飲店-雲科店",
      address: "斗六鎮學府路1號",
      manager: "王小明",
    },
    {
      id: "S002",
      name: "某某餐飲店-虎尾店",
      address: "虎尾鎮中山路88號",
      manager: "李小華",
    },
  ],
  inventory: [
    {
      storeId: "S001",
      sku: "ING-001",
      name: "雞胸肉",
      unit: "公斤",
      qty: 18,
      low: 10,
      exp: "2025-09-10",
    },
    {
      storeId: "S001",
      sku: "ING-002",
      name: "高筋麵粉",
      unit: "包",
      qty: 35,
      low: 20,
      exp: "2026-01-05",
    },
    {
      storeId: "S002",
      sku: "ING-001",
      name: "雞胸肉",
      unit: "公斤",
      qty: 9,
      low: 10,
      exp: "2025-09-08",
    },
  ],
  ingredients: [
    {
      sku: "ING-001",
      name: "雞胸肉",
      cost: 120,
      unit: "公斤",
      supplier: "好食公司",
    },
    {
      sku: "ING-002",
      name: "高筋麵粉",
      cost: 45,
      unit: "包",
      supplier: "麥香行",
    },
  ],
  roleGroups: [
    {
      id: "RG-BOSS",
      name: "老闆",
      permissions: [
        "INV_READ",
        "ING_READ",
        "ING_WRITE",
        "STORE_CFG",
        "ORDER_CFG",
        "ROLE_CFG",
      ],
    },
    { id: "RG-EMP", name: "員工", permissions: ["INV_READ", "ING_READ"] },
    {
      id: "RG-CK",
      name: "中央廚房",
      permissions: ["INV_READ", "ING_READ", "ING_WRITE"],
    },
  ],
  settings: {
    store: { allowNegativeStock: false, defaultStoreId: "S001" },
    order: { autoApproval: true, notifyEmail: "boss@example.com" },
  },
};
