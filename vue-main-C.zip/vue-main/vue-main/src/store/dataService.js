const KEY = 'smart-inv-demo';

export function ensureSeed(seed) {
  const raw = localStorage.getItem(KEY);
  if (!raw) localStorage.setItem(KEY, JSON.stringify(seed));
}

export function readAll() {
  const raw = localStorage.getItem(KEY);
  return raw ? JSON.parse(raw) : null;
}

export function writeAll(payload) {
  localStorage.setItem(KEY, JSON.stringify(payload));
}

export function update(fn) {
  const data = readAll();
  const next = fn(structuredClone(data));
  writeAll(next);
  return next;
}
