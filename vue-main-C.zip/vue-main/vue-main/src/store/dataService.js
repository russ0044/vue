// src/store/dataService.js

const KEY = 'smart-inv-demo'

/* ---------- 工具函式（簡短且共用） ---------- */
const normEmail = (e) => String(e || '').trim().toLowerCase()
const int = (v, min = -Infinity) => Math.max(min, Math.trunc(Number(v) || 0))
const nextId = (prefix, n) => `${prefix}${String(n + 1).padStart(3, '0')}`

/* ---------- 核心 I/O ---------- */
export function ensureSeed(seed) {
  // 首次運行寫入種子，避免白屏
  if (!localStorage.getItem(KEY)) localStorage.setItem(KEY, JSON.stringify(seed))
}

export function readAll() {
  const raw = localStorage.getItem(KEY)
  if (!raw) return null
  let d
  try { d = JSON.parse(raw) } catch { return null }

  // 自動補欄位（避免 undefined 造成畫面錯誤）
  d.users ??= []
  d.roleGroups ??= []
  d.stores ??= []
  d.thresholds ??= []
  d.ingredients ??= []
  d.inventory ??= []
  d.inventoryChanges ??= []
  d.settings ??= {}
  d.settings.store ??= { defaultStoreId: d.stores[0]?.id || '' }
  return d
}

export function writeAll(payload) {
  localStorage.setItem(KEY, JSON.stringify(payload))
}

export function update(mutator) {
  const data = readAll()
  if (!data) throw new Error('資料未初始化：請先呼叫 ensureSeed()')
  const next = mutator(structuredClone(data))
  writeAll(next)
  return next
}

/* ---------- 註冊 / 使用者 ---------- */
export function emailExists(email) {
  const d = readAll()
  return d.users.some(u => normEmail(u.email) === normEmail(email))
}
export function addUser({ email, name, phone, roleGroupId }) {
  return update(d => {
    if (!email || !name) throw new Error('缺少必要欄位（email/name）')
    if (emailExists(email)) throw new Error('此電子郵件已被註冊，請使用其他信箱註冊')
    const id = nextId('U', d.users.length)
    d.users.push({ id, email, name, phone: String(phone || ''), roleGroupId, createdAt: Date.now() })
    return d
  })
}

/* ---------- 店面 ---------- */
export function addStore({ name, address, phone, type = 'branch' }) {
  return update(d => {
    if (!name) throw new Error('店面名稱不得為空')
    if (d.stores.some(s => s.name === name)) throw new Error('店面名稱已存在')
    const id = nextId('S', d.stores.length)
    d.stores.push({ id, name, address: String(address || ''), phone: String(phone || ''), type })
    d.thresholds.push({ storeId: id, minQty: 10, expDays: 3 })
    return d
  })
}
export function renameStore(id, newName) {
  return update(d => {
    if (!newName) throw new Error('店面名稱不得為空')
    if (d.stores.some(s => s.name === newName && s.id !== id)) throw new Error('店面名稱已存在')
    const i = d.stores.findIndex(s => s.id === id)
    if (i > -1) d.stores[i].name = newName
    return d
  })
}
export function deleteStore(id) {
  // 依 UC-13：刪店面會連動門檻/庫存/異動
  return update(d => {
    d.stores = d.stores.filter(s => s.id !== id)
    d.thresholds = d.thresholds.filter(t => t.storeId !== id)
    d.inventory = d.inventory.filter(i => i.storeId !== id)
    d.inventoryChanges = d.inventoryChanges.filter(c => c.storeId !== id)
    return d
  })
}

/* ---------- 警示門檻 ---------- */
export function saveThreshold(storeId, { minQty, expDays }) {
  return update(d => {
    if (!storeId) throw new Error('缺少 storeId')
    const rec = { storeId, minQty: int(minQty, 0), expDays: int(expDays, 0) }
    const idx = d.thresholds.findIndex(t => t.storeId === storeId)
    if (idx > -1) d.thresholds[idx] = rec
    else d.thresholds.push(rec)
    return d
  })
}

/* ---------- 庫存異動（UC-03） ---------- */
export function recordInventoryChange(change) {
  // change: {storeId, sku, name, delta, reason, operatorId, unit?, exp?}
  return update(d => {
    // 基本檢核（避免髒資料）
    if (!change?.storeId || !change?.sku || !change?.name) throw new Error('缺少必要欄位（storeId/sku/name）')
    const delta = int(change.delta) // 允許字串數字，統一轉整數
    if (!delta) throw new Error('異動數量不得為 0')
    if (!change.reason) throw new Error('請填寫異動原因')

    // 異動紀錄
    const id = `CHG-${String(d.inventoryChanges.length + 1).padStart(4, '0')}`
    d.inventoryChanges.push({ id, ...change, delta, at: Date.now() })

    // 實際庫存
    const idx = d.inventory.findIndex(x => x.storeId === change.storeId && x.sku === change.sku)
    if (idx > -1) {
      const nextQty = (d.inventory[idx].qty || 0) + delta
      if (nextQty < 0) throw new Error('庫存不得為負數')
      d.inventory[idx] = {
        ...d.inventory[idx],
        qty: nextQty,
        exp: change.exp || d.inventory[idx].exp
      }
    } else {
      if (delta < 0) throw new Error('新建品項不可為負異動')
      d.inventory.push({
        storeId: change.storeId,
        sku: change.sku,
        name: change.name,
        unit: String(change.unit || ''),
        qty: delta,
        low: 10,                   // 預設低庫存門檻（可由 store 門檻覆寫）
        exp: change.exp || ''
      })
    }
    return d
  })
}
