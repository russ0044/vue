// src/store/roleStore.js
// -------------------------------------------------------------
// 簡易角色 / 權限管理
// 目前預設為 Boss，後續可依登入帳號自動帶入。
// -------------------------------------------------------------
import { reactive } from 'vue'

// 狀態（角色＋權限清單）
const state = reactive({
  role: 'Boss', // 預設角色：Boss（之後可由登入時決定）
  permissions: [
    'INV_READ',     // 庫存查詢
    'INV_WRITE',    // 庫存異動
    'ING_READ',     // 食材查詢
    'ING_WRITE',    // 食材編輯
    'STORE_CFG',    // 店面設定
    'ROLE_CFG',     // 權限管理
    'ORDER_MGMT',   // 訂單管理
    'REPORT_VIEW'   // 報表檢視
  ]
})

export function useRoleStore() {
  return {
    state,

    // 切換角色（簡單版，實務上應由登入帶入）
    setRole(r) { state.role = r },

    // 檢查是否有指定權限
    hasPerm(p) { return state.permissions.includes(p) }
  }
}
