import { reactive, computed } from 'vue';

const state = reactive({
  role: 'Boss', // 'Boss' | 'Employee' | 'Kitchen'
});

export const useRoleStore = () => {
  const badge = computed(() => {
    switch (state.role) {
      case 'Boss': return { text: '老闆', color: '#2563eb' };      // 藍色
      case 'Employee': return { text: '員工', color: '#16a34a' };  // 綠色
      case 'Kitchen': return { text: '中央廚房', color: '#f59e0b' };// 橘色
    }
  });
  return {
    state,
    setRole: (r) => (state.role = r),
    badge,
    hasPerm: (perm, data) => {
      const rg = data.roleGroups.find(g => (state.role === 'Boss' && g.id==='RG-BOSS')
        || (state.role === 'Employee' && g.id==='RG-EMP')
        || (state.role === 'Kitchen' && g.id==='RG-CK'));
      return rg?.permissions?.includes(perm);
    }
  };
};
