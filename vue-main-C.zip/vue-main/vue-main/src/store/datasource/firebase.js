// src/store/datasource/firebase.js
// ---------------------------------------------------------
// Firebase 資料層（未來要改成呼叫 Firestore / Firebase Auth）
// ⚠ 目前僅為佔位函式，呼叫會直接丟出錯誤。
// ---------------------------------------------------------

// 初始化種子：Firebase 不需要本地 seed，所以這裡是空操作
export function ensureSeed() {
  /* no-op; Firebase 無須預設種子 */
}

// === 使用者 ===
export function emailExists() {
  throw new Error('TODO: 查詢 Firestore users 或 Firebase Auth')
}
export function addUser() {
  throw new Error('TODO: 使用 Firebase Auth 建立帳號 + Firestore 寫入 profile')
}

// === 店面與門檻 ===
export function addStore() {
  throw new Error('TODO: Firestore 新增 store')
}
export function renameStore() {
  throw new Error('TODO: Firestore 更新 store 名稱')
}
export function deleteStore() {
  throw new Error('TODO: Firestore 批次刪除 / 或 soft delete')
}
export function saveThreshold() {
  throw new Error('TODO: Firestore 更新 threshold 設定')
}

// === 庫存與異動 ===
export function recordInventoryChange() {
  throw new Error('TODO: transaction 更新庫存 + 寫入異動紀錄')
}

// === 讀取資料 ===
export function read() {
  throw new Error('TODO: Firestore 查詢 collections')
}
