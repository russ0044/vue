// src/store/dataService.js
// -------------------------------------------------------------
// 統一資料來源（Data Source）
// 可切換：localStorage 版（開發/預覽用）、Firebase 版（正式雲端用）
// 只需修改 active 變數，就能全站換後端。
// -------------------------------------------------------------

import * as local from './local'
import * as fb    from './firebase'

// ⚡ 切換資料來源： 'local' | 'firebase'
const active = 'local'  // TODO: 正式環境改成 'firebase'

// 導出統一 API，頁面端只需 import { ds }，不用管是哪個來源
export const ds = active === 'firebase' ? fb : local
