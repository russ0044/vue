// src/store/local.js
// --------------------------------------------------
// 使用 localStorage 的本地資料層 (開發/預覽用)
// ⚠ 正式環境建議切換到 firebase.js
// --------------------------------------------------

const KEY = 'smart-inv-demo'

// 初始化種子資料
export function ensureSeed(seed) {
  if (!localStorage.getItem(KEY)) {
    localStorage.setItem(KEY, JSON.stringify(seed))
  }
}

// 讀取整份資料
function readAll() {
  const raw = localStorage.getItem(KEY)
  if (!raw) return null
  const d = JSON.parse(raw)
  // 確保結構完整
  d.users ??= []
  d.roleGroups ??= []
  d.stores ??= []
  d.thresholds ??= []
  d.ingredients ??= []
  d.inventory ??= []
  d.inventoryChanges ??= []
  d.settings ??= { store: { defaultStoreId: d.stores[0]?.id || '' } }
  return d
}

// 寫回整份資料
function writeAll(d) {
  localStorage.setItem(KEY, JSON.stringify(d))
}

// 更新工具：clone -> 修改 -> 寫回
function update(fn) {
  const next = fn(structuredClone(readAll()))
  writeAll(next)
  return next
}

// === Auth-ish (示意) ===
export function emailExists(email) {
  return readAll().users.some(u => u.email.toLowerCase() === String(email).toLowerCase())
}
export function addUser({ email, name, phone, roleGroupId }) {
  return update(d => {
    const id = `U${String(d.users.length + 1).padStart(3, '0')}`
    d.users.push({ id, email, name, phone, roleGroupId, createdAt: Date.now() })
    return d
  })
}

// === Store / Threshold ===
export function addStore({ name, address, phone, type = 'branch' }) {
  return update(d => {
    if (d.stores.some(s => s.name === name)) throw new Error('店面名稱已存在')
    const id = `S${String(d.stores.length + 1).padStart(3, '0')}`
    d.stores.push({ id, name, address, phone, type })
    d.thresholds.push({ storeId: id, minQty: 10, expDays: 3 })
    return d
  })
}
export function renameStore(id, newName) {
  return update(d => {
    if (d.stores.some(s => s.name === newName && s.id !== id)) throw new Error('店面名稱已存在')
    const i = d.stores.findIndex(s => s.id === id)
    if (i > -1) d.stores[i].name = newName
    return d
  })
}
export function deleteStore(id) {
  return update(d => {
    d.stores = d.stores.filter(s => s.id !== id)
    d.thresholds = d.thresholds.filter(t => t.storeId !== id)
    d.inventory = d.inventory.filter(i => i.storeId !== id)
    d.inventoryChanges = d.inventoryChanges.filter(c => c.storeId !== id)
    return d
  })
}
export function saveThreshold(storeId, { minQty, expDays }) {
  return update(d => {
    const i = d.thresholds.findIndex(t => t.storeId === storeId)
    const rec = { storeId, minQty: Math.max(0, Math.floor(minQty)), expDays: Math.max(0, Math.floor(expDays)) }
    if (i > -1) d.thresholds[i] = rec
    else d.thresholds.push(rec)
    return d
  })
}

// === Inventory ===
export function recordInventoryChange(change) {
  return update(d => {
    const id = `CHG-${String(d.inventoryChanges.length + 1).padStart(4, '0')}`
    d.inventoryChanges.push({ id, ...change, at: Date.now() })
    const idx = d.inventory.findIndex(x => x.storeId === change.storeId && x.sku === change.sku)

    if (idx > -1) {
      const next = (d.inventory[idx].qty || 0) + change.delta
      if (next < 0) throw new Error('庫存不得為負數')
      d.inventory[idx] = { ...d.inventory[idx], qty: next, exp: change.exp || d.inventory[idx].exp }
    } else {
      if (change.delta < 0) throw new Error('新建品項不可為負異動')
      d.inventory.push({
        storeId: change.storeId,
        sku: change.sku,
        name: change.name,
        unit: change.unit || '',
        qty: change.delta,
        low: 10,
        exp: change.exp || ''
      })
    }
    return d
  })
}

// === 快速讀取 ===
export function read() {
  return readAll()
}

// === 食材資料管理 (UC-11) ===
export function listIngredients() {
  const d = readAll()
  return d?.ingredients || []
}
export function addIngredient(payload) {
  return update(d => {
    if (d.ingredients.some(x => x.name === payload.name)) throw new Error('名稱已重複，請重新輸入')
    const sku = payload.sku?.trim() || genSku(d) // 若沒填 SKU 自動產生
    d.ingredients.push({
      sku,
      name: payload.name.trim(),
      unit: payload.unit?.trim() || '',
      cost: Number(payload.cost || 0),
      supplier: payload.supplier?.trim() || ''
    })
    return d
  })
}
function genSku(d) {
  const i = d.ingredients.length + 1
  return `HCH-${String(i).padStart(3, '0')}`
}
export function updateIngredient(sku, patch) {
  return update(d => {
    const idx = d.ingredients.findIndex(x => x.sku === sku)
    if (idx < 0) throw new Error('查無此食材')
    if (patch.name && d.ingredients.some(x => x.name === patch.name && x.sku !== sku)) {
      throw new Error('名稱已重複，請重新輸入')
    }
    d.ingredients[idx] = { ...d.ingredients[idx], ...patch }
    return d
  })
}
export function deleteIngredient(sku) {
  return update(d => {
    const used = d.inventory.some(i => i.sku === sku && (i.qty || 0) > 0)
    if (used) throw new Error('該食材仍存在庫存，請先清空庫存再刪除')
    d.ingredients = d.ingredients.filter(x => x.sku !== sku)
    return d
  })
}

// === 邀請碼相關 ===
function ensureInvitesShape(d) {
  d.invites = Array.isArray(d.invites) ? d.invites : []
  return d
}
export function getInviteByCode(code) {
  const d = ensureInvitesShape(readAll())
  return d.invites.find(i => i.code === String(code).trim())
}
export function verifyInvite(code) {
  const rec = getInviteByCode(code)
  if (!rec) return { ok: false, reason: 'not_found' }
  if (rec.used) return { ok: false, reason: 'used' }
  if (Date.now() >= rec.expiresAt) return { ok: false, reason: 'expired' }
  return { ok: true, role: rec.role, note: rec.note, expiresAt: rec.expiresAt, id: rec.id, code: rec.code }
}
export function markInviteUsed(code) {
  return update(d => {
    ensureInvitesShape(d)
    const idx = d.invites.findIndex(i => i.code === code)
    if (idx > -1) d.invites[idx].used = true
    return d
  })
}
