import { reactive } from 'vue';

const KEY = 'smart-inv-auth';

const saved = localStorage.getItem(KEY);
const state = reactive(saved ? JSON.parse(saved) : {
  authed: false,
  user: null,               // { name, role: 'Boss' | 'Employee' | 'Kitchen' }
});

function persist(){ localStorage.setItem(KEY, JSON.stringify(state)); }

export function useAuth(){
  return {
    state,
    login({ name, role }){
      state.authed = true;
      state.user = { name: name?.trim() || '未命名使用者', role };
      persist();
    },
    logout(){
      state.authed = false;
      state.user = null;
      persist();
    }
  }
}
