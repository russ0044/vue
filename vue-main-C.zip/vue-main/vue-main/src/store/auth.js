// src/store/auth.js
import { reactive } from 'vue'
const KEY = 'smart-inv-auth'
const VERSION = 1 // 簡單版本號：之後 schema 變更可用來做相容處理

// 安全載入：避免壞 JSON 造成應用掛掉
function safeLoad() {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return null
    const obj = JSON.parse(raw)
    if (!obj || typeof obj !== 'object') return null
    if (obj.version !== VERSION) return null
    // 最少需要 authed / user 結構
    if (typeof obj.authed !== 'boolean') return null
    return obj
  } catch {
    return null
  }
}

// 初始狀態（避免空白頁）
const initial = safeLoad() ?? { version: VERSION, authed: false, user: null }
const state = reactive(initial)

// 寫回 localStorage（僅此處統一處理）
function persist() {
  localStorage.setItem(KEY, JSON.stringify(state))
}

// 跨分頁同步登入狀態
window.addEventListener('storage', (e) => {
  if (e.key !== KEY) return
  const next = safeLoad()
  if (!next) return
  state.authed = next.authed
  state.user = next.user
})

export function useAuth() {
  return {
    state,

    // 登入：可傳入更多欄位，統一收斂
    // 例：login({ id, email, name, role, roleGroupId })
    login(payload) {
      state.authed = true
      // 僅保留必要資訊，避免把敏感 token 放在 localStorage
      const { id = null, email = null, name = '', role = '', roleGroupId = null } = payload || {}
      state.user = { id, email, name, role, roleGroupId, lastLoginAt: Date.now() }
      state.version = VERSION
      persist()
    },

    // 登出：清除狀態與儲存
    logout() {
      state.authed = false
      state.user = null
      state.version = VERSION
      persist()
    },

    // 便捷判斷（介面/權限切換用）
    isBoss() {
      return state.user?.role === 'Boss'
    },
    isEmployee() {
      return state.user?.role === 'Employee'
    },
    isKitchen() {
      return state.user?.role === 'Kitchen'
    },

    // 重置儲存（除錯/切環境）
    resetStorage() {
      localStorage.removeItem(KEY)
      state.authed = false
      state.user = null
      state.version = VERSION
    }
  }
}
