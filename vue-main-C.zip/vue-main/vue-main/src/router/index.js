// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import { useAuth } from '../store/auth'
import Boss from '../view/Boss.vue'

// 懶載入頁面
const LoginView        = () => import('../view/LoginView.vue')
const RegisterView     = () => import('../view/RegisterView.vue')
const BossInventory    = () => import('../view/boss/BossInventory.vue')
const BossIngredients  = () => import('../view/boss/BossIngredients.vue')
const BossRoleGroups   = () => import('../view/boss/BossRoleGroups.vue')
const BossStoreSettings= () => import('../view/boss/BossStoreSettings.vue')
const BossOrderSettings= () => import('../view/boss/BossOrderSettings.vue')
const BossThresholds   = () => import('../view/boss/BossThresholds.vue')
const BossStores       = () => import('../view/boss/BossStores.vue')
const BossInvite       = () => import('../view/boss/BossInvite.vue')
const BossReports      = () => import('../view/boss/BossReports.vue')
const NotFound         = () => import('../view/NotFound.vue')

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login',    name: 'login',    component: LoginView,    meta:{ title:'登入' } },
  { path: '/register', name: 'register', component: RegisterView, meta:{ title:'註冊' } },
  {
    path: '/boss',
    component: Boss,
    meta: { requiresAuth: true },
    children: [
      { path: '', redirect: '/boss/inventory' },
      { path: 'inventory',      name: 'boss-inventory',   component: BossInventory,    meta:{ title:'店面庫存', requiresAuth:true } },
      { path: 'ingredients',    name: 'boss-ingredients', component: BossIngredients,  meta:{ title:'食材資料', requiresAuth:true } },
      { path: 'rolegroups',     name: 'boss-rolegroups',  component: BossRoleGroups,   meta:{ title:'群組權限', requiresAuth:true } },
      { path: 'stores',         name: 'boss-stores',      component: BossStores,       meta:{ title:'店面管理', requiresAuth:true } },
      { path: 'thresholds',     name: 'boss-thresholds',  component: BossThresholds,   meta:{ title:'警示門檻', requiresAuth:true } },
      { path: 'store-settings', name: 'boss-store-settings', component: BossStoreSettings, meta:{ title:'店面設定', requiresAuth:true } },
      { path: 'order-settings', name: 'boss-order-settings', component: BossOrderSettings, meta:{ title:'訂單設定', requiresAuth:true } },
      { path: 'invite',         name: 'boss-invite',      component: BossInvite,       meta:{ title:'邀請新成員', requiresAuth:true } },
      { path: 'reports',        name: 'boss-reports',     component: BossReports,      meta:{ title:'報表中心', requiresAuth:true } },
    ]
  },
  { path: '/:pathMatch(.*)*', name:'not-found', component: NotFound, meta:{ title:'頁面不存在' } }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior: () => ({ top:0 }) // 切頁自動回頂
})

// 全域守門：檢查登入
router.beforeEach((to,_from,next)=>{
  const { state } = useAuth()
  const authed = !!state?.authed
  const needAuth = to.matched.some(r=>r.meta?.requiresAuth)

  if (needAuth && !authed) return next({ name:'login' }) // 未登入 → 導回登入
  if (!needAuth && authed && to.name==='login') return next({ name:'boss-inventory' }) // 已登入卻進登入頁 → 導去 boss
  next()
})

// 後置：設定標題
router.afterEach(to=>{
  const base = '餐易館'
  document.title = to.meta?.title ? `${to.meta.title}｜${base}` : base
})

export default router
