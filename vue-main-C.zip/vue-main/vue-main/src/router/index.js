import { createRouter, createWebHistory } from 'vue-router';
import Boss from '../view/Boss.vue';
import BossInventory from '../view/boss/BossInventory.vue';
import BossIngredients from '../view/boss/BossIngredients.vue';
import BossRoleGroups from '../view/boss/BossRoleGroups.vue';
import BossStoreSettings from '../view/boss/BossStoreSettings.vue';
import BossOrderSettings from '../view/boss/BossOrderSettings.vue';

const routes = [
  { path: '/', redirect: '/boss' },
  {
    path: '/boss',
    component: Boss,
    children: [
      { path: '', redirect: '/boss/inventory' },
      { path: 'inventory', component: BossInventory },
      { path: 'ingredients', component: BossIngredients },
      { path: 'rolegroups', component: BossRoleGroups },
      { path: 'store-settings', component: BossStoreSettings },
      { path: 'order-settings', component: BossOrderSettings },
    ]
  },
  // 之後再開：/employee, /kitchen
];

const router = createRouter({ history: createWebHistory(), routes });
export default router;

