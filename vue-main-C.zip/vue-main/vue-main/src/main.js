import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { ensureSeed } from './store/dataService'
import { seedData } from './data/seed'

ensureSeed(seedData);
createApp(App).use(router).mount('#app')
