import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { ds } from './store/datasource'
import { seedData } from './data/seed'
import './assets/theme.css'

// 寫入種子資料（local 來源才需要）
ds.ensureSeed?.(seedData)

createApp(App).use(router).mount('#app')
