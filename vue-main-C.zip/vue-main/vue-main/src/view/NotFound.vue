<template>
  <div class="card" style="margin:40px auto;max-width:560px;padding:24px;text-align:center">
    <h2>頁面不存在</h2>
    <p class="muted">請檢查網址或回登入頁</p>
    <router-link class="btn primary" to="/login">返回登入</router-link>
  </div>
</template>
<script setup></script>
<style scoped>.muted{color:var(--muted)}</style>
