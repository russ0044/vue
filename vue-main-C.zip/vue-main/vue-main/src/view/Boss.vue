<template>
  <div class="screen">
    <header class="topbar">
      <div class="brand">
        <!-- 手機版漢堡選單 -->
        <button class="hamburger" @click="menuOpen=!menuOpen" aria-label="開關選單">☰</button>
        <div class="avatar"></div>
        <div>
          <div class="title">某某餐飲店</div>
          <div class="sub">ID: 123456789</div>
        </div>
      </div>

      <div class="right">
        <RoleBadge />
        <!-- 齒輪設定＋登出 -->
        <SettingsButton
          @open-settings="go('store-settings')"
          @logout="doLogout"
        />
      </div>
    </header>

    <div class="body">
      <aside class="sidebar" :class="{open: menuOpen}">
        <button :class="btnClass('inventory')"   @click="goAndClose('inventory')">檢視店面庫存</button>
        <button :class="btnClass('ingredients')" @click="goAndClose('ingredients')">食材資料</button>
        <button :class="btnClass('rolegroups')"  @click="goAndClose('rolegroups')">群組權限</button>
        <button :class="btnClass('store-settings')" @click="goAndClose('store-settings')">店面設定</button>
        <button :class="btnClass('order-settings')" @click="goAndClose('order-settings')">訂單設定</button>
      </aside>

      <main class="content">
        <router-view />
      </main>
    </div>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import RoleBadge from '../components/RoleBadge.vue';
import SettingsButton from '../components/SettingsButton.vue';
import { useAuth } from '../store/auth';   // for 登出用

const route = useRoute();
const router = useRouter();
const { logout } = useAuth();

const current = computed(() => route.path.split('/').pop());
const menuOpen = ref(false);

const go = (name) => router.push(`/boss/${name}`);
const goAndClose = (name) => { go(name); menuOpen.value = false; };
const btnClass = (name) => ['navbtn', current.value === name ? 'active' : ''].join(' ');
const doLogout = () => { logout(); router.push('/login'); };
</script>

<style scoped>
/* 外框與頂欄 */
.screen{max-width:1100px;margin:16px auto;background:#f8fafc;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);overflow:hidden}
.topbar{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:#fff;border-bottom:1px solid #e5e7eb}
.brand{display:flex;gap:10px;align-items:center}
.avatar{width:38px;height:38px;border-radius:50%;background:#e5e7eb}
.title{font-weight:700}
.sub{font-size:.85rem;color:#64748b}
.right{display:flex;align-items:center;gap:10px}

/* 主體與側欄 */
.body{display:flex;min-height:540px}
.sidebar{width:280px;padding:16px;background:#fff;border-right:1px solid #e5e7eb;display:flex;flex-direction:column;gap:12px}
.navbtn{padding:14px 16px;border:1px solid #d1d5db;border-radius:14px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.03);text-align:center}
.navbtn:hover{transform:translateY(-1px);box-shadow:0 4px 14px rgba(0,0,0,.08)}
.navbtn.active{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.12)}
.content{flex:1;padding:18px}

/* 手機版調整 */
.hamburger{display:none;margin-right:6px;border:1px solid #e5e7eb;background:#fff;border-radius:8px;padding:6px 10px}
@media (max-width: 768px){
  .screen{border-radius:0;box-shadow:none}
  .hamburger{display:block}
  .body{position:relative}
  .sidebar{
    position:absolute;left:0;top:0;bottom:0;width:78%;
    transform:translateX(-100%);transition:.2s ease;z-index:5;
    box-shadow:0 12px 30px rgba(0,0,0,.2)
  }
  .sidebar.open{transform:translateX(0)}
}
</style>
