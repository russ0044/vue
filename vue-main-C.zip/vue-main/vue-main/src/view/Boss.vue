<template>
  <div class="layout">
    <TopBar @toggle-menu="open=!open" @open-settings="go('/boss/store-settings')" />
    <div class="main">
      <aside class="card sidebar" :class="{open}">
        <router-link class="link" to="/boss/inventory">檢視店面庫存</router-link>
        <router-link class="link" to="/boss/ingredients">食材資料</router-link>
        <router-link class="link" to="/boss/rolegroups">群組權限</router-link>
        <router-link class="link" to="/boss/stores">店面管理</router-link>
        <router-link class="link" to="/boss/thresholds">警示門檻</router-link>
        <router-link class="link" to="/boss/store-settings">店面設定</router-link>
        <router-link class="link" to="/boss/order-settings">訂單設定</router-link>
        <router-link class="link" to="/boss/invite">邀請新成員</router-link>
        <router-link class="link" to="/boss/reports">報表中心</router-link>


      </aside>
      <main class="content card">
        <ErrorBoundary><router-view /></ErrorBoundary>
      </main>
    </div>
  </div>
</template>
<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import TopBar from '../components/TopBar.vue'
import ErrorBoundary from '../components/ErrorBoundary.vue'
const open = ref(false)
const router = useRouter()
function go(p){ router.push(p) }
</script>
<style scoped>
.layout{max-width:1200px;margin:16px auto;display:flex;flex-direction:column;gap:12px}
.main{display:grid;grid-template-columns:260px 1fr;gap:12px}
.sidebar{padding:12px;height:100%;position:sticky;top:12px}
.link{display:block;padding:10px 12px;border:1px solid #e2e8f0;border-radius:12px;text-decoration:none;margin-bottom:8px;color:var(--text);background:#fff}
.link:hover{box-shadow:0 4px 12px rgba(0,0,0,.08)}
.content{padding:12px;min-height:560px}
@media (max-width: 900px){
  .main{grid-template-columns:1fr}
  .sidebar{position:fixed;z-index:50;inset:0 auto 0 0;transform:translateX(-110%);max-width:80vw}
  .sidebar.open{transform:translateX(0)}
}
</style>
