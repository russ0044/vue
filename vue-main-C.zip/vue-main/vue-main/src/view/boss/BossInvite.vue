<template>
  <section>
    <h2 class="section-title">邀請新成員</h2>

    <div class="card" style="padding:12px">
      <div class="kit-toolbar">
        <label>角色
          <select class="input" v-model="role">
            <option value="Boss">老闆</option>
            <option value="Employee">員工</option>
            <option value="Kitchen">中央廚房</option>
          </select>
        </label>
        <label>有效天數
          <select class="input" v-model.number="days">
            <option :value="3">3 天</option>
            <option :value="7">7 天</option>
            <option :value="14">14 天</option>
            <option :value="30">30 天</option>
          </select>
        </label>
        <label style="flex:1">備註（可選）
          <input class="input" v-model.trim="note" placeholder="例如：門市新人 9/1 到職">
        </label>
        <button class="btn primary" @click="onGenerate">生成邀請碼</button>
      </div>

      <p v-if="msg" :class="ok ? 'ok' : 'err'">{{ msg }}</p>
    </div>

    <div class="card" style="margin-top:12px;overflow:auto">
      <table class="table">
        <thead>
          <tr>
            <th>邀請碼</th><th>角色</th><th>備註</th>
            <th>建立時間</th><th>到期時間</th><th>狀態</th><th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="i in rows" :key="i.id">
            <td><code>{{ i.code }}</code></td>
            <td>{{ roleLabel(i.role) }}</td>
            <td>{{ i.note || '-' }}</td>
            <td>{{ fmt(i.createdAt) }}</td>
            <td>{{ fmt(i.expiresAt) }}</td>
            <td>
              <span class="badge" :class="i.status==='valid'?'ok':'danger'">
                {{ i.status==='valid' ? '有效' : '已到期' }}
              </span>
            </td>
            <td>
              <button class="btn" @click="copy(i)">複製連結</button>
              <button class="btn ghost" @click="remove(i)">刪除</button>
            </td>
          </tr>
          <tr v-if="rows.length===0">
            <td colspan="7" style="text-align:center;color:var(--muted)">尚無邀請碼</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue'
import { listInvites, createInvite, revokeInvite, purgeExpiredInvites } from '../../store/dataService'

const role = ref('Employee')
const days = ref(7)
const note = ref('')
const msg = ref(''); const ok = ref(false)

const rows = computed(()=> listInvites() )

function onGenerate(){
  try{
    createInvite({ role: role.value, days: days.value, note: note.value })
    purgeExpiredInvites()
    ok.value=true; msg.value='已生成新的邀請碼'
    note.value=''
    setTimeout(()=> msg.value='', 900)
  }catch(e){ ok.value=false; msg.value=e.message || '生成失敗' }
}
function roleLabel(r){ return r==='Boss'?'老闆':r==='Kitchen'?'中央廚房':'員工' }
function fmt(t){ const d = new Date(t); const z = n=>String(n).padStart(2,'0'); return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())} ${z(d.getHours())}:${z(d.getMinutes())}` }
async function copy(i){
  const url = `${location.origin}/register?invite=${i.code}`
  try{ await navigator.clipboard.writeText(url); ok.value=true; msg.value='已複製連結' }
  catch{ ok.value=false; msg.value='複製失敗，請手動複製：'+url }
  setTimeout(()=> msg.value='', 1000)
}
function remove(i){
  if(!confirm('確定刪除這筆邀請？')) return
  revokeInvite(i.id)
}
</script>

<style scoped>
.ok{color:var(--success)} .err{color:var(--danger)}
code{background:#f1f5f9;padding:2px 6px;border-radius:6px}
</style>
