<template>
  <section>
    <h2>店面庫存</h2>
    <div class="toolbar">
      <label>店面：
        <select v-model="storeId">
          <option v-for="s in stores" :key="s.id" :value="s.id">{{ s.name }}</option>
        </select>
      </label>
      <input v-model="keyword" placeholder="搜尋品名 / SKU">
      <button class="primary" @click="openChange('add')">庫存變動</button>
    </div>

    <table>
      <thead><tr>
        <th @click="sortBy('sku')">SKU</th>
        <th @click="sortBy('name')">品名</th>
        <th @click="sortBy('qty')">數量</th>
        <th>安全量</th><th>單位</th>
        <th @click="sortBy('exp')">效期</th><th>狀態</th>
      </tr></thead>
      <tbody>
        <tr v-for="row in filteredSorted" :key="row.sku" @click="selectRow(row)">
          <td>{{ row.sku }}</td>
          <td>{{ row.name }}</td>
          <td>{{ row.qty }}</td>
          <td>{{ lowFor(row) }}</td>
          <td>{{ row.unit }}</td>
          <td>{{ row.exp }}</td>
          <td>
            <span :class="row.qty < lowFor(row) ? 'badge danger' : 'badge ok'">
              {{ row.qty < lowFor(row) ? '低於安全量' : 'OK' }}
            </span>
          </td>
        </tr>
      </tbody>
    </table>

    <p class="hint">提示：點擊列可帶入「庫存變動」的品項。</p>

    <Modal v-if="show" @close="show=false">
      <template #title>庫存變動管理</template>
      <div class="form">
        <label>操作類型
          <select v-model="mode">
            <option value="add">新增庫存（+）</option>
            <option value="modify">修改庫存（覆寫）</option>
            <option value="delete">刪除庫存（扣到 0）</option>
          </select>
        </label>
        <label>店面
          <select v-model="form.storeId">
            <option v-for="s in stores" :key="s.id" :value="s.id">{{ s.name }}</option>
          </select>
        </label>
        <label>SKU <input v-model.trim="form.sku" placeholder="ING-001"></label>
        <label>品名 <input v-model.trim="form.name" placeholder="雞胸肉"></label>
        <label>單位 <input v-model.trim="form.unit" placeholder="公斤/包…"></label>
        <label v-if="mode!=='delete'">數量 <input type="number" v-model.number="form.qty" placeholder="正整數"></label>
        <label>原因（必填） <input v-model.trim="form.reason" placeholder="盤點修正 / 退貨 / 報廢 …"></label>
        <label>效期（YYYY-MM-DD，可留空） <input v-model.trim="form.exp" placeholder="2025-12-31"></label>
        <p v-if="err" class="err">{{ err }}</p>
        <p v-if="saved" class="ok">已更新 ✔</p>
      </div>
      <template #actions>
        <button @click="show=false">取消</button>
        <button class="primary" @click="submit">確認送出</button>
      </template>
    </Modal>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue';
import { readAll, recordInventoryChange } from '../../store/dataService';
import Modal from '../../components/Modal.vue';

const d0 = readAll();
const stores = d0?.stores || [];
const storeId = ref(d0?.settings?.store?.defaultStoreId || stores[0]?.id || '');
const keyword = ref('');
const sortKey = ref('exp'); const sortAsc = ref(true);

const rows = computed(()=>{
  const data = readAll();
  if (!data) return [];
  return data.inventory.filter(i=>i.storeId===storeId.value);
});
const filteredSorted = computed(()=>{
  const kw = keyword.value.trim();
  let list = rows.value.filter(i => (i.name+i.sku).includes(kw));
  list = list.slice().sort((a,b)=>{
    const A = a[sortKey.value], B = b[sortKey.value];
    if(A==B) return 0; return (A>B?1:-1) * (sortAsc.value?1:-1);
  });
  return list;
});
function sortBy(k){ if(sortKey.value===k) sortAsc.value=!sortAsc.value; else {sortKey.value=k; sortAsc.value=true;} }

function lowFor(row){
  const d = readAll();
  if (!d) return row.low ?? 0;
  const t = d.thresholds?.find(x=>x.storeId===row.storeId);
  return t?.minQty ?? row.low ?? 0;
}

// 變動 Modal
const show = ref(false);
const mode = ref('add');
const saved = ref(false); const err = ref('');
const form = ref({ storeId: storeId.value, sku:'', name:'', unit:'', qty:0, reason:'', exp:'' });

function openChange(m){
  mode.value = m;
  form.value = { storeId: storeId.value, sku:'', name:'', unit:'', qty:0, reason:'', exp:'' };
  saved.value=false; err.value='';
  show.value = true;
}
function selectRow(r){
  show.value = true; mode.value='modify'; err.value=''; saved.value=false;
  form.value = { storeId: r.storeId, sku: r.sku, name: r.name, unit: r.unit, qty: r.qty, reason:'盤點修正', exp: r.exp };
}
function isPosInt(n){ return Number.isInteger(n) && n>0; }
function isNonNegInt(n){ return Number.isInteger(n) && n>=0; }
function validDate(s){ return !s || /^\d{4}-\d{2}-\d{2}$/.test(s); }

function submit(){
  err.value='';
  if(!form.value.sku || !form.value.name){ err.value='請輸入 SKU 與品名'; return; }
  if(!form.value.reason){ err.value='請填寫原因'; return; }
  if(!validDate(form.value.exp)){ err.value='效期格式必須為 YYYY-MM-DD'; return; }

  try{
    if(mode.value==='add'){
      if(!isPosInt(form.value.qty)){ err.value='新增數量須為正整數'; return; }
      recordInventoryChange({
        storeId: form.value.storeId, sku: form.value.sku, name: form.value.name,
        delta: form.value.qty, reason: form.value.reason, operatorId: 'U001', unit: form.value.unit, exp: form.value.exp
      });
    }else if(mode.value==='modify'){
      if(!isNonNegInt(form.value.qty)){ err.value='修改後數量須為整數且 >=0'; return; }
      const cur = readAll().inventory.find(x=>x.storeId===form.value.storeId && x.sku===form.value.sku);
      if(!cur){ err.value='查無此商品'; return; }
      const delta = form.value.qty - (cur.qty||0);
      recordInventoryChange({
        storeId: form.value.storeId, sku: form.value.sku, name: form.value.name,
        delta, reason: form.value.reason, operatorId: 'U001', unit: form.value.unit, exp: form.value.exp || cur.exp
      });
    }else{ // delete
      const cur = readAll().inventory.find(x=>x.storeId===form.value.storeId && x.sku===form.value.sku);
      if(!cur){ err.value='刪除失敗：查無此商品'; return; }
      if((cur.qty||0)<=0){ err.value='刪除失敗：庫存為 0'; return; }
      recordInventoryChange({
        storeId: form.value.storeId, sku: form.value.sku, name: cur.name,
        delta: -(cur.qty||0), reason: form.value.reason, operatorId: 'U001', unit: cur.unit, exp: cur.exp
      });
    }
    saved.value = true;
    setTimeout(()=>{ show.value=false; }, 600);
  }catch(e){
    err.value = e.message || '儲存失敗，請稍後重試';
  }
}
</script>

<style scoped>
h2{margin:4px 0 12px;font-size:1.25rem}
.toolbar{display:flex;gap:12px;margin-bottom:12px;flex-wrap:wrap}
input,select{padding:8px;border:1px solid #d1d5db;border-radius:8px}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.05)}
th,td{padding:10px 12px;border-bottom:1px solid #eef2f7;cursor:default}
th{user-select:none}
.badge{padding:2px 8px;border-radius:999px;font-size:.8rem}
.badge.ok{background:#e8f3ff}
.badge.danger{background:#ffe8e8}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:10px 14px}
.hint{color:#64748b;margin:8px 0}
.form label{display:flex;flex-direction:column;gap:6px;margin:6px 0}
.err{color:#dc2626} .ok{color:#16a34a}
</style>
