<template>
  <section>
    <h2>店面庫存</h2>
    <div class="toolbar">
      <label>店面：
        <select v-model="storeId">
          <option v-for="s in data.stores" :key="s.id" :value="s.id">{{ s.name }}</option>
        </select>
      </label>
      <input v-model="keyword" placeholder="搜尋品名 / SKU">
    </div>

    <table>
      <thead><tr><th>SKU</th><th>品名</th><th>數量</th><th>安全量</th><th>單位</th><th>效期</th><th>狀態</th></tr></thead>
      <tbody>
        <tr v-for="row in filtered" :key="row.sku">
          <td>{{ row.sku }}</td>
          <td>{{ row.name }}</td>
          <td>
            <input type="number" v-model.number="row.qty" min="0" style="width:80px">
          </td>
          <td>{{ row.low }}</td>
          <td>{{ row.unit }}</td>
          <td>{{ row.exp }}</td>
          <td>
            <span :class="row.qty < row.low ? 'badge danger' : 'badge ok'">
              {{ row.qty < row.low ? '低於安全量' : 'OK' }}
            </span>
          </td>
        </tr>
      </tbody>
    </table>

    <div class="actions">
      <button class="primary" @click="save">儲存變更</button>
      <span v-if="saved" class="hint">已儲存 ✔</span>
    </div>
  </section>
</template>

<script setup>
import { ref, computed } from 'vue';
import { readAll, update } from '../../store/dataService';

const data = readAll();
const storeId = ref(data.settings.store.defaultStoreId);
const keyword = ref('');
const saved = ref(false);

const filtered = computed(()=>{
  return data.inventory
    .filter(i=>i.storeId===storeId.value)
    .map(i => ({...i}))
    .filter(i => (i.name+i.sku).includes(keyword.value.trim()));
});

function save(){
  const rows = filtered.value;
  update(d=>{
    rows.forEach(r=>{
      const idx = d.inventory.findIndex(x=>x.storeId===r.storeId && x.sku===r.sku);
      if(idx>-1) d.inventory[idx].qty = r.qty;
    });
    return d;
  });
  saved.value = true;
  setTimeout(()=>saved.value=false, 1200);
}
</script>

<style scoped>
h2{margin:4px 0 12px;font-size:1.25rem}
.toolbar{display:flex;gap:12px;margin-bottom:12px}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.05)}
th,td{padding:10px 12px;border-bottom:1px solid #eef2f7}
.badge{padding:2px 8px;border-radius:999px;font-size:.8rem}
.badge.ok{background:#e8f3ff}
.badge.danger{background:#ffe8e8}
.actions{display:flex;align-items:center;gap:10px;margin-top:12px}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:10px 14px}
.hint{color:#16a34a}
</style>
