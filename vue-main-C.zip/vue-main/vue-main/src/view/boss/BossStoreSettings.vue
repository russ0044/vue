<template>
  <section>
    <h2>店面設定</h2>
    <div class="card">
      <label>預設店面：
        <select v-model="settings.store.defaultStoreId">
          <option v-for="s in data.stores" :key="s.id" :value="s.id">{{ s.name }}</option>
        </select>
      </label>
      <label class="row">
        <input type="checkbox" v-model="settings.store.allowNegativeStock">
        允許負庫存（僅測試用）
      </label>
    </div>
    <button class="primary" @click="save">儲存</button>
    <span v-if="saved" class="hint">已儲存 ✔</span>
  </section>
</template>

<script setup>
import { reactive, ref } from 'vue';
import { readAll, update } from '../../store/dataService';
const data = readAll();
const settings = reactive(JSON.parse(JSON.stringify(data.settings)));
const saved = ref(false);
function save(){ update(d=>({ ...d, settings })); saved.value=true; setTimeout(()=>saved.value=false,1200); }
</script>

<style scoped>
.card{background:#fff;padding:14px;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.05);display:flex;flex-direction:column;gap:12px;margin-bottom:12px}
.row{display:flex;align-items:center;gap:8px}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:10px 14px}
.hint{color:#16a34a;margin-left:8px}
</style>
