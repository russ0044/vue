<template>
  <section>
    <h2 class="section-title">報表中心</h2>

    <div class="kit-grid cols-2">
      <div class="card" style="padding:12px">
        <h3>關鍵指標</h3>
        <ul class="kpis">
          <li><span>總品項數</span><strong>{{ kpi.totalItems }}</strong></li>
          <li><span>低於門檻</span><strong>{{ kpi.lowCount }}</strong></li>
          <li><span>即將到期</span><strong>{{ kpi.expSoon }}</strong></li>
          <li><span>今日異動</span><strong>{{ kpi.todayChanges }}</strong></li>
        </ul>
      </div>

      <div class="card" style="padding:12px">
        <h3>工具</h3>
        <div class="kit-toolbar">
          <button class="btn" @click="exportCSV('inventory')">匯出庫存 CSV</button>
          <button class="btn" @click="exportCSV('changes')">匯出近 30 天異動 CSV</button>
        </div>
        <p class="muted">* 之後可加 PNG/PDF；接 Firebase 後改抓雲端資料即可。</p>
      </div>
    </div>

    <div class="card" style="margin-top:12px;padding:12px">
      <h3>近 7 天庫存異動</h3>
      <div class="chart-wrap">
        <svg :width="svg.w" :height="svg.h" role="img" aria-label="近 7 天庫存異動長條圖">
          <g v-for="(d,i) in series" :key="i" :transform="`translate(${padL + i*barStep}, ${padT})`">
            <rect :x="0" :y="yScale(Math.max(0,d.value))" :width="barW"
                  :height="Math.abs(yScale(d.value)-yScale(0))"
                  :fill="d.value>=0 ? '#2563eb' : '#dc2626'"/>
            <text :x="barW/2" :y="svg.h-padB+14" text-anchor="middle" font-size="12">{{ d.label }}</text>
          </g>
          <!-- x=0 基準線 -->
          <line :x1="padL" :x2="svg.w-padR" :y1="yScale(0)" :y2="yScale(0)" stroke="#cbd5e1" />
        </svg>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed } from 'vue'
import { readAll } from '../../store/dataService'

const d = readAll()

/* KPI */
const kpi = computed(()=>{
  const th = Object.fromEntries(d.thresholds.map(t=>[t.storeId,t]))
  const inv = d.inventory
  const lowCount = inv.filter(i=> (i.qty||0) < (th[i.storeId]?.minQty ?? i.low ?? 0)).length
  const expSoon = inv.filter(i=>{
    if(!i.exp) return false
    const t = new Date(i.exp).getTime() - Date.now()
    const days = t/(1000*60*60*24)
    const rule = th[i.storeId]?.expDays ?? 3
    return days >= 0 && days <= rule
  }).length
  const t0 = new Date(); t0.setHours(0,0,0,0)
  const todayChanges = d.inventoryChanges.filter(c=>c.at>=t0.getTime()).length
  return {
    totalItems: new Set(inv.map(i=>i.sku)).size,
    lowCount, expSoon, todayChanges
  }
})

/* 近 7 天變動圖 */
const days = [...Array(7)].map((_,k)=>{
  const dt = new Date(); dt.setDate(dt.getDate()-(6-k)); dt.setHours(0,0,0,0)
  return dt
})
const group = days.map(dt=>{
  const next = new Date(dt); next.setDate(dt.getDate()+1)
  const arr = d.inventoryChanges.filter(c=> c.at>=dt.getTime() && c.at<next.getTime())
  const sum = arr.reduce((s,c)=> s + (c.delta||0), 0)
  return { label:`${dt.getMonth()+1}/${dt.getDate()}`, value: sum }
})
const series = computed(()=> group)

/* 簡易 SVG 參數與比例 */
const svg = { w: 820, h: 260 }
const padL=40, padR=20, padT=10, padB=30
const barStep = (svg.w - padL - padR) / series.value.length
const barW = Math.max(12, barStep * 0.6)
const maxAbs = Math.max(10, ...series.value.map(s=>Math.abs(s.value)))
const yScale = (v)=> {
  const top = padT, bottom = svg.h - padB
  // 將 -maxAbs ~ +maxAbs 映射到 bottom ~ top
  return bottom - ( (v + maxAbs) / (2*maxAbs) ) * (bottom - top)
}

/* 匯出 CSV（庫存 or 異動） */
function exportCSV(type){
  if(type==='inventory'){
    const rows = [['storeId','sku','name','unit','qty','exp']]
    d.inventory.forEach(i=> rows.push([i.storeId,i.sku,i.name,i.unit,i.qty,i.exp||'']))
    downloadCsv(rows, 'inventory.csv')
  }else{
    const rows = [['at','storeId','sku','name','delta','reason','operatorId']]
    d.inventoryChanges
      .sort((a,b)=>a.at-b.at)
      .forEach(c=> rows.push([fmt(c.at),c.storeId,c.sku,c.name,c.delta,c.reason,c.operatorId]))
    downloadCsv(rows, 'inventory_changes_30d.csv')
  }
}
function downloadCsv(rows, filename){
  const content = rows.map(r=> r.map(x=>{
    const s = String(x??'')
    return `"${s.replace(/"/g,'""')}"`
  }).join(',')).join('\r\n')
  const blob = new Blob([content], {type:'text/csv;charset=utf-8;'})
  const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=filename; a.click()
  setTimeout(()=>URL.revokeObjectURL(a.href), 0)
}
function fmt(t){ const d = new Date(t); const z = n=>String(n).padStart(2,'0'); return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())} ${z(d.getHours())}:${z(d.getMinutes())}` }
</script>

<style scoped>
.kpis{list-style:none;display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:0;margin:8px 0}
.kpis li{background:#f8fbff;border:1px solid #e6eefb;border-radius:12px;padding:10px 12px}
.kpis span{color:var(--muted);font-size:.9rem}
.kpis strong{display:block;font-size:1.3rem}
.muted{color:var(--muted)}
.chart-wrap{overflow:auto}
@media (max-width: 860px){ .kpis{grid-template-columns:repeat(2,1fr)} }
</style>
