<template>
  <section>
    <h2>警示門檻設定</h2>
    <table>
      <thead><tr><th>店面</th><th>最低庫存</th><th>效期天數</th><th>動作</th></tr></thead>
      <tbody>
        <tr v-for="s in stores" :key="s.id">
          <td>{{ s.name }}</td>
          <td><input type="number" v-model.number="rows[s.id].minQty" min="0"></td>
          <td><input type="number" v-model.number="rows[s.id].expDays" min="0"></td>
          <td><button class="primary" @click="save(s.id)">儲存</button></td>
        </tr>
      </tbody>
    </table>
    <p v-if="msg" class="ok">{{ msg }}</p>
  </section>
</template>

<script setup>
import { reactive, ref } from 'vue';
import { readAll, saveThreshold } from '../../store/dataService';
const data = readAll();
const stores = data.stores;
const rows = reactive(Object.fromEntries(stores.map(s=>{
  const t = data.thresholds.find(x=>x.storeId===s.id) || {minQty:10,expDays:3};
  return [s.id, { minQty: t.minQty, expDays: t.expDays }];
})));
const msg = ref('');
function save(storeId){
  const { minQty, expDays } = rows[storeId];
  if(minQty<0 || expDays<0){ msg.value='請輸入非負整數'; return; }
  saveThreshold(storeId, {minQty, expDays});
  msg.value='門檻設定成功 ✔'; setTimeout(()=>msg.value='', 1000);
}
</script>

<style scoped>
h2{margin:4px 0 12px;font-size:1.25rem}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.05)}
th,td{padding:10px 12px;border-bottom:1px solid #eef2f7}
input{width:120px;padding:6px;border:1px solid #d1d5db;border-radius:8px}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:8px 12px}
.ok{color:#16a34a;margin-top:8px}
</style>
