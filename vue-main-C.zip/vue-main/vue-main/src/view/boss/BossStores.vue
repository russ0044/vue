<template>
  <section>
    <h2>店面管理</h2>
    <div class="row">
      <div class="card">
        <h3>店面列表</h3>
        <table>
          <thead><tr><th>ID</th><th>名稱</th><th>地址</th><th>電話</th><th>類型</th><th>操作</th></tr></thead>
          <tbody>
            <tr v-for="s in stores" :key="s.id" :class="{sel: s.id===selId}" @click="select(s.id)">
              <td>{{ s.id }}</td><td>{{ s.name }}</td><td>{{ s.address }}</td><td>{{ s.phone }}</td><td>{{ s.type }}</td>
              <td>
                <button @click.stop="edit(s)">編輯</button>
                <button @click.stop="remove(s)">刪除</button>
              </td>
            </tr>
          </tbody>
        </table>

        <details class="mt">
          <summary>新增店面</summary>
          <div class="form">
            <label>名稱<input v-model.trim="f.name"></label>
            <label>地址<input v-model.trim="f.address"></label>
            <label>電話<input v-model.trim="f.phone"></label>
            <label>類型
              <select v-model="f.type"><option value="branch">門市</option><option value="central">中央廚房</option></select>
            </label>
            <button class="primary" @click="create">新增</button>
            <span class="ok" v-if="msg">{{ msg }}</span>
          </div>
        </details>
      </div>

      <div class="card">
        <h3>營運概況</h3>
        <p v-if="!selId">請點選左側任一店面</p>
        <div v-else>
          <p>店面：<strong>{{ current?.name }}</strong></p>
          <ul class="stats">
            <li>低於門檻品項：{{ stat.lowCount }}</li>
            <li>即將到期品項：{{ stat.expSoon }}</li>
            <li>今日異動：{{ stat.todayChanges }}</li>
          </ul>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { reactive, ref, computed } from 'vue';
import { readAll, addStore, deleteStore, renameStore } from '../../store/dataService';

const stores = ref(readAll().stores);
const selId = ref('');
const f = reactive({ name:'', address:'', phone:'', type:'branch' });
const msg = ref('');

function refresh(){ stores.value = readAll().stores; }
function create(){
  try{
    if(!f.name || !f.address || !f.phone){ msg.value='請填寫完整'; return; }
    addStore({...f});
    Object.assign(f, {name:'',address:'',phone:'',type:'branch'});
    msg.value='新增成功'; setTimeout(()=>msg.value='', 800);
    refresh();
  }catch(e){ alert(e.message || '新增失敗'); }
}
function select(id){ selId.value = id; }
function edit(s){
  const name = prompt('新名稱', s.name); if(!name) return;
  try{ renameStore(s.id, name); refresh(); } catch(e){ alert(e.message || '修改失敗'); }
}
function remove(s){
  const hasInv = readAll().inventory.some(i=>i.storeId===s.id);
  if(hasInv && !confirm('該店仍有庫存資料，確定仍要刪除？')) return;
  deleteStore(s.id); refresh();
  if(selId.value===s.id) selId.value='';
}
const current = computed(()=> stores.value.find(s=>s.id===selId.value));
const stat = computed(()=>{
  if(!current.value) return {lowCount:0, expSoon:0, todayChanges:0};
  const d = readAll();
  const th = d.thresholds.find(t=>t.storeId===current.value.id) || {minQty:10,expDays:3};
  const inv = d.inventory.filter(i=>i.storeId===current.value.id);
  const lowCount = inv.filter(i=> (i.qty||0) < th.minQty).length;
  const expSoon = inv.filter(i=>{
    if(!i.exp) return false;
    const diff = (new Date(i.exp).getTime() - Date.now()) / (1000*60*60*24);
    return diff >=0 && diff <= th.expDays;
  }).length;
  const t0 = new Date(); t0.setHours(0,0,0,0);
  const todayChanges = d.inventoryChanges.filter(c=>c.storeId===current.value.id && c.at>=t0.getTime()).length;
  return {lowCount, expSoon, todayChanges};
});
</script>

<style scoped>
h2{margin:4px 0 12px;font-size:1.25rem}
.row{display:grid;grid-template-columns:1.4fr .8fr;gap:14px}
.card{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.05);padding:12px}
table{width:100%;border-collapse:collapse}
th,td{padding:8px 10px;border-bottom:1px solid #eef2f7}
.mt{margin-top:10px}
.form label{display:flex;flex-direction:column;gap:4px;margin:6px 0}
input,select{padding:6px;border:1px solid #d1d5db;border-radius:8px}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:8px 12px}
.ok{color:#16a34a;margin-left:8px}
.sel{background:#f8fafc}
.stats{display:flex;gap:12px;list-style:none;padding:0;margin:10px 0}
@media (max-width: 860px){ .row{grid-template-columns:1fr} }
</style>
