<template>
  <section>
    <h2>訂單設定</h2>
    <div class="card">
      <label class="row"><input type="checkbox" v-model="settings.order.autoApproval"> 自動核准補貨單</label>
      <label>通知信箱：<input v-model="settings.order.notifyEmail" placeholder="boss@example.com"></label>
    </div>
    <button class="primary" @click="save">儲存</button>
    <span v-if="saved" class="hint">已儲存 ✔</span>
  </section>
</template>

<script setup>
import { reactive, ref } from 'vue';
import { readAll, update } from '../../store/dataService';
const data = readAll();
const settings = reactive(JSON.parse(JSON.stringify(data.settings)));
const saved = ref(false);
function save(){ update(d=>({ ...d, settings })); saved.value=true; setTimeout(()=>saved.value=false,1200); }
</script>

<style scoped>
.card{background:#fff;padding:14px;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.05);display:flex;flex-direction:column;gap:12px;margin-bottom:12px}
.row{display:flex;align-items:center;gap:8px}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:10px 14px}
.hint{color:#16a34a;margin-left:8px}
</style>
