<template>
  <section>
    <h2>食材資料</h2>
    <table>
      <thead><tr><th>SKU</th><th>名稱</th><th>單位</th><th>成本</th><th>供應商</th></tr></thead>
      <tbody>
        <tr v-for="(g,i) in rows" :key="g.sku">
          <td>{{ g.sku }}</td>
          <td><input v-model="rows[i].name"></td>
          <td><input v-model="rows[i].unit" style="width:72px"></td>
          <td><input type="number" v-model.number="rows[i].cost" style="width:90px"></td>
          <td><input v-model="rows[i].supplier"></td>
        </tr>
      </tbody>
    </table>
    <div class="actions">
      <button class="primary" @click="save">儲存變更</button>
      <button @click="add">新增一筆</button>
      <span v-if="saved" class="hint">已儲存 ✔</span>
    </div>
  </section>
</template>

<script setup>
import { ref } from 'vue';
import { readAll, update } from '../../store/dataService';
const data = readAll();
const rows = ref(data.ingredients.map(x=>({...x})));
const saved = ref(false);
function save(){
  update(d=>({ ...d, ingredients: rows.value }));
  saved.value = true; setTimeout(()=>saved.value=false, 1200);
}
function add(){
  rows.value.push({ sku:`ING-${String(rows.value.length+1).padStart(3,'0')}`, name:'', unit:'個', cost:0, supplier:'' });
}
</script>

<style scoped>
h2{margin:4px 0 12px;font-size:1.25rem}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.05)}
th,td{padding:10px 12px;border-bottom:1px solid #eef2f7}
.actions{display:flex;align-items:center;gap:10px;margin-top:12px}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:10px 14px}
.hint{color:#16a34a}
</style>
