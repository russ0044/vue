<template>
  <section>
    <h2>群組權限</h2>
    <table>
      <thead><tr><th>群組</th><th>權限</th></tr></thead>
      <tbody>
        <tr v-for="g in groups" :key="g.id">
          <td>{{ g.name }}</td>
          <td class="chips">
            <label v-for="p in allPerms" :key="p">
              <input type="checkbox" :checked="g.permissions.includes(p)" @change="toggle(g,p)"> {{ p }}
            </label>
          </td>
        </tr>
      </tbody>
    </table>
    <div class="actions">
      <button class="primary" @click="save">儲存變更</button>
      <span v-if="saved" class="hint">已儲存 ✔</span>
    </div>
  </section>
</template>

<script setup>
import { ref } from 'vue';
import { readAll, update } from '../../store/dataService';
const data = readAll();
const groups = ref(data.roleGroups.map(x=>({...x, permissions:[...x.permissions]})));
const allPerms = ['INV_READ','ING_READ','ING_WRITE','STORE_CFG','ORDER_CFG','ROLE_CFG'];
const saved = ref(false);

function toggle(g,perm){
  const i = g.permissions.indexOf(perm);
  i>-1 ? g.permissions.splice(i,1) : g.permissions.push(perm);
}
function save(){
  update(d=>({ ...d, roleGroups: groups.value }));
  saved.value = true; setTimeout(()=>saved.value=false, 1200);
}
</script>

<style scoped>
h2{margin:4px 0 12px;font-size:1.25rem}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.05)}
th,td{padding:10px 12px;border-bottom:1px solid #eef2f7;vertical-align:top}
.chips{display:flex;flex-wrap:wrap;gap:10px}
label{background:#f1f5f9;padding:6px 10px;border-radius:999px}
.actions{display:flex;align-items:center;gap:10px;margin-top:12px}
.primary{background:#2563eb;color:#fff;border:none;border-radius:10px;padding:10px 14px}
.hint{color:#16a34a}
</style>
