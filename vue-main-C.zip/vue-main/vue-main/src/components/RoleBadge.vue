<template>
  <span class="badge" :data-role="role">{{ text }}</span>
</template>

<script setup>
import { computed } from 'vue'
import { useRoleStore } from '../store/roleStore'
const { state } = useRoleStore()
const role = computed(()=> state.role)
const text = computed(()=> role.value==='Boss'?'老闆':role.value==='Employee'?'員工':'中央廚房')
</script>

<style scoped>
.badge{padding:6px 10px;border-radius:999px;font-size:.85rem}
.badge[data-role="Boss"]{background:#e7f3ff;color:#1e40af}
.badge[data-role="Employee"]{background:#e8fce7;color:#166534}
.badge[data-role="Kitchen"]{background:#fff3e6;color:#a16207}
</style>
