<template>
  <div class="role-badge" :style="{ borderColor: badge.color }" title="目前角色">
    <span class="dot" :style="{ background: badge.color }"></span>
    <strong>{{ badge.text }}</strong>
  </div>
</template>

<script setup>
import { useRoleStore } from '../store/roleStore';
const { badge } = useRoleStore();
</script>

<style scoped>
.role-badge{
  display:flex;align-items:center;gap:.5rem;
  border:2px solid transparent;border-radius:999px;padding:.25rem .6rem;
  background:#fff; box-shadow:0 2px 10px rgba(0,0,0,.06);
}
.dot{width:.75rem;height:.75rem;border-radius:999px;}
</style>
