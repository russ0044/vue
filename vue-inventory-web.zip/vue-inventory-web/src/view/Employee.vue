<template>
  <div class="screen">
    <!-- 頂部列 -->
    <header class="topbar">
      <div class="brand">
        <div class="avatar">🏪</div>
        <div>
          <div class="title">某某餐飲（門市）</div>
          <div class="sub">店：{{ scope.storeName }}</div>
        </div>
      </div>

      <div class="actions">
        <button class="icon-btn" title="系統設定" @click="goSettings">⚙</button>
        <!-- 若已經有 RoleBadge 元件就用它；沒有的話下面有一個簡單樣式 -->
        <RoleBadge v-if="hasRoleBadge" />
        <span v-else class="role-pill">員工</span>
        <button class="logout" @click="onLogout">登出</button>
      </div>
    </header>

    <!-- 主體 -->
    <div class="body">
      <aside class="sidebar">
        <RouterLink
          :to="{ name:'emp-inventory' }"
          class="navbtn"
          :class="{active: current==='emp-inventory'}"
        >門市庫存</RouterLink>

        <RouterLink
          :to="{ name:'emp-orders' }"
          class="navbtn"
          :class="{active: current==='emp-orders'}"
          v-can="'orders.view'"
        >訂單情況</RouterLink>

        <RouterLink
          :to="{ name:'emp-reports' }"
          class="navbtn"
          :class="{active: current==='emp-reports'}"
          v-can="'reports.view'"
        >檢視報表</RouterLink>

        <RouterLink
          :to="{ name:'emp-delivery' }"
          class="navbtn"
          :class="{active: current==='emp-delivery'}"
          v-can="'delivery.view'"
        >配送情況</RouterLink>
      </aside>

      <main class="content">
        <RouterView />
      </main>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuth } from '@/store/auth'
import { useScope } from '@/store/scope'
import { usePerm } from '@/store/perm'

// 如果你專案裡已有 RoleBadge 就保留；沒有可刪這行
import RoleBadge from '@/components/RoleBadge.vue'

const hasRoleBadge = true // 若沒有元件可改成 false

const route = useRoute()
const router = useRouter()
const { logout } = useAuth()
const scope = useScope()
usePerm().ensureLoaded()

const current = computed(() => String(route.name || ''))

function goSettings(){ router.push('/settings') }
function onLogout(){
  logout()
  router.replace({ name:'login' })
}
</script>

<style scoped>
/* — 外殼與頂欄（與截圖一致） — */
.screen{max-width:1180px;margin:16px auto;background:#f8fafc;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);overflow:hidden}
.topbar{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;background:#fff;border-bottom:1px solid #e5e7eb}
.brand{display:flex;gap:12px;align-items:center}
.avatar{width:42px;height:42px;border-radius:50%;background:#e5e7eb;display:grid;place-items:center;font-size:18px}
.title{font-weight:700}
.sub{font-size:.85rem;color:#64748b}
.actions{display:flex;align-items:center;gap:12px}

/* 圖示按鈕（圓形描邊） */
.icon-btn{background:#fff;border:1px solid #d1d5db;border-radius:50%;width:36px;height:36px;cursor:pointer;font-size:18px;line-height:1;display:flex;align-items:center;justify-content:center}
.icon-btn:hover{background:#f1f5f9}

/* 角色膠囊（若沒有 RoleBadge 元件時使用） */
.role-pill{padding:.28rem .6rem;border-radius:999px;background:#eef2ff;color:#1d4ed8;border:1px solid #dbeafe;font-weight:600}

/* 登出 */
.logout{background:#ef4444;color:#fff;border:none;padding:6px 12px;border-radius:8px;cursor:pointer;font-size:14px}
.logout:hover{background:#dc2626}

/* 主體與側欄（與老闆頁一致） */
.body{display:flex;min-height:560px}
.sidebar{width:260px;padding:16px;background:#fff;border-right:1px solid #e5e7eb;display:flex;flex-direction:column;gap:12px}
.navbtn{padding:14px 16px;border:1px solid #d1d5db;border-radius:14px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.03);text-align:center;cursor:pointer;color:inherit;text-decoration:none}
.navbtn:hover{transform:translateY(-1px);box-shadow:0 4px 14px rgba(0,0,0,.08)}
.navbtn.active{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.12)}
.content{flex:1;padding:18px}
</style>
