﻿<template>
  <section>
    <!-- 篩選工具列 -->
    <div class="toolbar">
      <label class="row">
        <span class="muted">起</span><input type="date" class="input" v-model="from">
        <span class="muted">迄</span><input type="date" class="input" v-model="to">
      </label>
      <label class="row">
        <span>狀態：</span>
        <select v-model="status" class="input">
          <option value="">全部</option>
          <option value="pending">待出貨</option>
          <option value="shipped">已出貨</option>
        </select>
      </label>
      <div class="spacer"></div>
      <button class="btn" @click="apply">套用</button>
      <button class="btn ghost" @click="exportCSV">匯出 CSV</button>
      <button class="btn ghost" @click="exportJSON">匯出 JSON</button>
    </div>

    <!-- KPI 卡片 -->
    <div class="cards">
      <div class="card stat"><div class="label">總訂單</div><div class="value">{{ rows.length }}</div></div>
      <div class="card stat"><div class="label">待出貨</div><div class="value">{{ rows.filter(r=>r.status==='pending').length }}</div></div>
      <div class="card stat"><div class="label">已出貨</div><div class="value">{{ rows.filter(r=>r.status==='shipped').length }}</div></div>
    </div>

    <!-- 訂單表（和報表同樣卡片/表格風格） -->
    <div class="card table">
      <div class="h2">訂單清單</div>
      <div class="thead">
        <div class="c no">單號</div>
        <div class="c store">門市</div>
        <div class="c items">品項數</div>
        <div class="c qty">總數量</div>
        <div class="c status">狀態</div>
        <div class="c act">操作</div>
      </div>
      <div class="row" v-for="o in rows" :key="o.id">
        <div class="c no mono">{{ o.no }}</div>
        <div class="c store">{{ o.store }}</div>
        <div class="c items">{{ o.items.length }}</div>
        <div class="c qty mono">{{ o.items.reduce((s,i)=>s+i.qty,0) }}</div>
        <div class="c status">
          <span :class="['pill', o.status]">{{ o.status==='pending' ? '待出貨' : '已出貨' }}</span>
        </div>
        <div class="c act">
          <button class="icon small" v-if="o.status==='pending'" @click="ship(o)">出貨</button>
          <button class="icon small danger" @click="remove(o.id)">刪除</button>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'

const from = ref(offset(-6))
const to = ref(offset(0))
const status = ref('')

const all = ref(mock())

const rows = computed(()=>{
  return all.value.filter(o=>{
    const inRange = o.date>=from.value && o.date<=to.value
    const ok = !status.value || o.status===status.value
    return inRange && ok
  })
})

function ship(o){ o.status='shipped' }
function remove(id){ if(confirm('確定刪除？')) all.value = all.value.filter(x=>x.id!==id) }
function apply(){ /* 資料已即時計算，這裡可接 API */ }

function exportCSV(){
  const header = ['日期','單號','門市','狀態','品項數','總數量']
  const rowsCSV = rows.value.map(o=>[
    o.date, o.no, o.store, (o.status==='pending'?'待出貨':'已出貨'),
    o.items.length, o.items.reduce((s,i)=>s+i.qty,0)
  ].join(','))
  const content = '\uFEFF' + [header.join(','), ...rowsCSV].join('\n')
  download('ck-orders.csv', content)
}
function exportJSON(){ download('ck-orders.json', JSON.stringify(rows.value, null, 2)) }
function download(name, content){ const blob=new Blob([content],{type:'text/plain;charset=utf-8'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; a.click(); URL.revokeObjectURL(a.href) }

function offset(d){ const t=new Date(); t.setDate(t.getDate()+d); return t.toISOString().slice(0,10) }
function mock(){
  const stores=['A 門市','B 門市','C 門市']; const items=['雞腿','洋蔥','番茄','蠔油','雞胸']
  const arr=[]
  for(let i=0;i<30;i++){
    const date = offset(-i)
    for(const s of stores){
      const has = Math.random()>0.5
      if(!has) continue
      const n = 1+Math.floor(Math.random()*4)
      const order = {
        id:Date.now()+Math.random(), date, no:`CK-${date.replaceAll('-','').slice(2)}-${Math.floor(Math.random()*900+100)}`,
        store:s, status: Math.random()>0.5?'pending':'shipped',
        items: Array.from({length:n},()=>({ name: items[Math.floor(Math.random()*items.length)], qty: 1+Math.floor(Math.random()*20) }))
      }
      arr.push(order)
    }
  }
  return arr
}
</script>

<style scoped>
<style scoped>
/* ===== 主題變數（與其它頁一致） ===== */
:root{
  --bg:#f6faf8;
  --card:#fff;
  --text:#000;          /* 全站黑字 */
  --muted:#2f3a48;      /* 次要字也偏黑 */
  --line:#e5e7eb;

  --primary:#28c7a5;    /* 薄荷綠主色 */
  --primary-weak:#e6fbf6;
  --blue:#2563eb;
  --blue-weak:#e8f0ff;

  --shadow:0 8px 24px rgba(15,23,42,.08);
  --radius-lg:16px;
  --radius-md:12px;
}

/* 全域：黑字 + 平滑字型 */
section, section *{ color:var(--text) !important; -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; }
::placeholder{ color:#333 !important; }
section{ background:var(--bg); }

/* ===== 工具列 ===== */
.toolbar{
  display:flex; gap:12px; align-items:center; flex-wrap:wrap; margin-bottom:12px;
  padding:12px 14px; background:var(--card); border:1px solid var(--line);
  border-radius:var(--radius-lg); box-shadow:var(--shadow);
}
.row{ display:flex; gap:8px; align-items:center; }
.spacer{ flex:1; }

/* 控件與按鈕 */
.input, select, .btn{
  border:1px solid var(--line); background:#fff; border-radius:12px;
  height:34px; padding:0 10px; font-size:14px; max-width:100%;
}
.btn{
  font-weight:800; color:#000 !important;
  background:var(--primary); box-shadow:0 4px 12px rgba(40,199,165,.15);
}
.btn.ghost{ background:#fff; box-shadow:none; }
.btn:hover{ filter:brightness(1.02); }
.btn:active{ transform:translateY(1px); }

/* ===== KPI 卡片 ===== */
.cards{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin:12px 0; }
.card{
  background:var(--card); border:1px solid var(--line); border-radius:var(--radius-lg);
  padding:14px; box-shadow:var(--shadow); min-width:0;
}
.stat .label{ color:var(--muted) !important; font-size:.9rem; }
.stat .value{ font-size:1.5rem; font-weight:900; }

/* ===== 清單表格（grid 表頭+列） ===== */
.card.table{ padding:0; overflow:hidden; }
.card.table .h2{
  font-weight:900; padding:14px; margin:0; border-bottom:1px solid var(--line);
  background:linear-gradient(0deg,#fff, #fff), linear-gradient(#f8fafc,#f8fafc);
}
.thead, .row{
  display:grid; align-items:center; gap:8px; padding:10px 12px;
  grid-template-columns:1.4fr 1fr 100px 120px 120px 160px;
}
.thead{
  background:#f8fafc; font-weight:800; border-bottom:1px solid var(--line);
}
.row{
  border-bottom:1px solid #eef2f6; background:#fff;
}
.row:hover{ background:#fcfffd; }

/* 狀態膠囊 */
.pill{
  display:inline-flex; align-items:center; gap:6px;
  padding:.14rem .6rem; border-radius:999px; font-weight:800; border:1px solid transparent;
  background:#fff;
}
.pill.pending{ background:#fff7ed; border-color:#fed7aa; color:#b45309; }
.pill.shipped{ background:#ecfdf5; border-color:#a7f3d0; color:#047857; }

/* 操作按鈕（小型 icon 風） */
.icon.small{
  border:1px solid var(--line); background:#fff; border-radius:10px;
  padding:4px 8px; cursor:pointer; margin-right:6px; height:30px;
  display:inline-flex; align-items:center; justify-content:center;
}
.icon.small:hover{ box-shadow:0 2px 8px rgba(15,23,42,.12); }
.icon.small.danger{ border-color:#fecaca; }

.mono{ font-family: ui-monospace, Menlo, Consolas, monospace; }

/* ===== RWD ===== */
@media (max-width:900px){
  .cards{ grid-template-columns:1fr; }
  .thead, .row{ grid-template-columns:1fr .9fr 80px 100px 100px 120px; }
}
</style>
