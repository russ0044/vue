﻿<template>
  <section>
    <!-- 篩選工具列 -->
    <div class="toolbar">
      <label class="row">
        <span class="muted">起</span><input type="date" class="input" v-model="from">
        <span class="muted">迄</span><input type="date" class="input" v-model="to">
      </label>
      <label class="row">
        <span>維度：</span>
        <select v-model="dim" class="input">
          <option value="item">品項</option>
          <option value="store">門市</option>
          <option value="route">車次</option>
        </select>
      </label>
      <div class="spacer"></div>
      <button class="btn" @click="recalc">套用</button>
      <button class="btn ghost" @click="exportCSV">匯出 CSV</button>
      <button class="btn ghost" @click="exportJSON">匯出 JSON</button>
    </div>

    <!-- KPI 卡片 -->
    <div class="cards">
      <div class="card stat"><div class="label">出貨單數</div><div class="value">{{ kpi.orders }}</div></div>
      <div class="card stat"><div class="label">總出貨量</div><div class="value">{{ kpi.qty }}</div></div>
      <div class="card stat"><div class="label">總金額</div><div class="value">\${{ kpi.amount.toLocaleString() }}</div></div>
    </div>

    <!-- 圖表區：圓餅圖 + 日出貨趨勢 -->
    <div class="grid">
      <!-- Donut / Pie -->
      <div class="card">
        <div class="h2">出貨比例（{{ labelOfDim }}）</div>
        <svg viewBox="0 0 360 260" class="chart">
          <g transform="translate(110,130)">
            <!-- 背景圈 -->
            <circle :r="outerR" fill="#f8fafc" stroke="#eef2f6" />
            <!-- 切片 -->
            <template v-for="(s,i) in slices" :key="s.name">
              <path :d="s.d" :fill="s.color" stroke="#fff" stroke-width="1" />
            </template>
            <!-- 中心資訊 -->
            <g class="donut-center">
              <text text-anchor="middle" y="-4" font-size="18" font-weight="900">{{ topCount }}</text>
              <text text-anchor="middle" y="14" font-size="11" class="muted">TOP 項目</text>
            </g>
          </g>

          <!-- 圖例 -->
          <g transform="translate(210,18)">
            <template v-for="(s,i) in slices" :key="'lg-'+i">
              <rect :y="i*20" width="12" height="12" :fill="s.color" rx="2" />
              <text x="18" :y="i*20+10" font-size="12">
                {{ s.name }}（{{ s.percent }}% / {{ s.val }}）
              </text>
            </template>
            <template v-if="!slices.length">
              <text x="0" y="12" font-size="12" class="muted">沒有資料</text>
            </template>
          </g>
        </svg>
      </div>

      <!-- Trend 折線 -->
      <div class="card">
        <div class="h2">日出貨趨勢</div>
        <svg viewBox="0 0 640 260" class="chart">
          <polyline :points="trendPoints" fill="none" stroke="currentColor" stroke-width="2"/>
          <g v-for="(p,i) in trend" :key="i">
            <circle :cx="60+i*stepX" :cy="220 - p*stepY" r="3"/>
          </g>
          <line x1="50" y1="220" x2="600" y2="220" class="axis"/>
        </svg>
      </div>
    </div>

    <!-- 明細：彙總表 -->
    <div class="card table">
      <div class="h2">彙總表（{{ labelOfDim }}）</div>
      <div class="thead">
        <div class="c name">{{ labelOfDim }}</div>
        <div class="c qty">數量</div>
        <div class="c amt">金額</div>
        <div class="c share">占比</div>
      </div>
      <div class="row" v-for="r in table" :key="r.name">
        <div class="c name">{{ r.name }}</div>
        <div class="c qty mono">{{ r.qty }}</div>
        <div class="c amt mono">\${{ r.amount.toLocaleString() }}</div>
        <div class="c share">{{ (r.qty/Math.max(1,kpi.qty)*100).toFixed(1) }}%</div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'

/* ===== 篩選狀態 ===== */
const from = ref(offset(-6))
const to = ref(offset(0))
const dim = ref('item')  // item | store | route

/* ===== 資料（模擬） ===== */
const dataset = ref(mock()) // 每天各門市/車次/品項出貨

/* ===== KPI ===== */
const kpi = computed(()=>{
  const rows = withinRange()
  return {
    orders: rows.length,
    qty: rows.reduce((s,r)=>s+r.qty,0),
    amount: rows.reduce((s,r)=>s+r.qty*r.price,0),
  }
})
const labelOfDim = computed(()=> ({item:'品項',store:'門市',route:'車次'})[dim.value])

/* ===== 彙總表資料 ===== */
const table = computed(()=>{
  const rows = withinRange()
  const map = new Map()
  for(const r of rows){
    const key = r[dim.value]
    const entry = map.get(key) || {name:key, qty:0, amount:0}
    entry.qty += r.qty
    entry.amount += r.qty*r.price
    map.set(key, entry)
  }
  return [...map.values()].sort((a,b)=>b.qty-a.qty)
})

/* ===== 圓餅圖切片（取 Top N） ===== */
const colors = ['#60a5fa','#93c5fd','#38bdf8','#22d3ee','#2dd4bf','#4ade80','#facc15','#f87171','#c084fc','#a3e635']
const topN = 8
const outerR = 90
const innerR = 52
const topCount = computed(()=> Math.min(table.value.length, topN))

const slices = computed(()=>{
  const top = table.value.slice(0, topN)
  const total = Math.max(1, top.reduce((s,t)=>s+t.qty,0))
  let acc = -Math.PI/2
  return top.map((r,i)=>{
    const share = r.qty/total
    const theta = share*2*Math.PI
    const start = acc, end = acc + theta; acc = end

    const x1 = Math.cos(start)*outerR, y1 = Math.sin(start)*outerR
    const x2 = Math.cos(end)*outerR,   y2 = Math.sin(end)*outerR
    const ix2= Math.cos(end)*innerR,   iy2= Math.sin(end)*innerR
    const ix1= Math.cos(start)*innerR, iy1= Math.sin(start)*innerR
    const large = theta > Math.PI ? 1 : 0

    // 圓環 path
    const d = `M ${x1} ${y1}
               A ${outerR} ${outerR} 0 ${large} 1 ${x2} ${y2}
               L ${ix2} ${iy2}
               A ${innerR} ${innerR} 0 ${large} 0 ${ix1} ${iy1}
               Z`

    return {
      name: r.name,
      val: r.qty,
      percent: (share*100).toFixed(1),
      d,
      color: colors[i % colors.length],
    }
  })
})

/* ===== 趨勢折線 ===== */
const trend = computed(()=>{
  const rows = withinRange()
  const days = daysBetween(from.value, to.value)+1
  const arr = Array.from({length:days},()=>0)
  rows.forEach(r=>{
    const idx = daysBetween(from.value, r.date)
    if(idx>=0 && idx<days) arr[idx]+=r.qty
  })
  return arr
})
const stepX = computed(()=> (540/Math.max(1,trend.value.length-1)))
const stepY = computed(()=>{
  const max = Math.max(1, ...trend.value)
  return 180/max
})
const trendPoints = computed(()=>{
  return trend.value.map((v,i)=>[60+i*stepX.value, 220 - v*stepY.value].join(',')).join(' ')
})

/* ===== 事件 / 匯出 ===== */
function withinRange(){ return dataset.value.filter(r=>r.date>=from.value && r.date<=to.value) }
function offset(d){ const t=new Date(); t.setDate(t.getDate()+d); return t.toISOString().slice(0,10) }
function daysBetween(a,b){ return Math.floor((new Date(b)-new Date(a))/(1000*3600*24)) }
function recalc(){ /* 已即時計算，這裡可接 API */ }

function exportCSV(){
  const header = ['日期','門市','車次','品項','數量','單價']
  const rows = withinRange().map(r=>[r.date,r.store,r.route,r.item,r.qty,r.price].join(','))
  download('kitchen-reports.csv', [header.join(','), ...rows].join('\n'))
}
function exportJSON(){ download('kitchen-reports.json', JSON.stringify(withinRange(),null,2)) }
function download(name, content){ const blob=new Blob([content],{type:'text/plain;charset=utf-8'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; a.click(); URL.revokeObjectURL(a.href) }

/* ===== 假資料 ===== */
function mock(){
  const stores = ['A 門市','B 門市','C 門市']; const routes=['A 車','B 車']
  const items = ['雞腿排','洋蔥','番茄','蠔油','九層塔','雞胸']
  const days = 21
  const arr=[]
  for(let i=0;i<days;i++){
    const date = offset(-i)
    for(const s of stores){
      for(const it of items){
        const qty = Math.floor(Math.random()*18)
        if(!qty) continue
        arr.push({date, store:s, route: routes[Math.floor(Math.random()*routes.length)], item:it, qty, price: 10+Math.floor(Math.random()*90)})
      }
    }
  }
  return arr
}
</script>

<style scoped>
/* ===== 主題變數（與員工/其他頁一致） ===== */
:root{
  --bg:#f6faf8;
  --card:#fff;
  --text:#000;
  --muted:#2f3a48;
  --line:#e5e7eb;

  --primary:#28c7a5;
  --primary-weak:#e6fbf6;
  --blue:#2563eb;
  --blue-weak:#e8f0ff;

  --shadow:0 8px 24px rgba(15,23,42,.08);
  --radius-lg:16px;
}

/* 全域黑字 + 背景 */
section, section *{ color:var(--text) !important; -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; }
::placeholder{ color:#333 !important; }
section{ background:var(--bg); }

/* 工具列 */
.toolbar{
  display:flex; gap:12px; align-items:center; flex-wrap:wrap; margin-bottom:12px;
  padding:12px 14px; background:var(--card); border:1px solid var(--line);
  border-radius:var(--radius-lg); box-shadow:var(--shadow);
}
.row{ display:flex; gap:8px; align-items:center; }
.spacer{ flex:1; }
.input, select, .btn{
  border:1px solid var(--line); background:#fff; border-radius:12px;
  height:34px; padding:0 10px; font-size:14px; max-width:100%;
}
.btn{ font-weight:800; color:#000 !important; background:var(--primary); box-shadow:0 4px 12px rgba(40,199,165,.15); }
.btn.ghost{ background:#fff; box-shadow:none; }

/* KPI 卡片 */
.cards{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin:12px 0; }
.card{
  background:var(--card); border:1px solid var(--line); border-radius:var(--radius-lg);
  padding:14px; box-shadow:var(--shadow); min-width:0;
}
.stat .label{ color:var(--muted) !important; font-size:.9rem; }
.stat .value{ font-size:1.5rem; font-weight:900; }

/* 圖表容器 */
.grid{ display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px; }
@media (max-width:900px){ .grid{ grid-template-columns:1fr; } }
.h2{ font-weight:900; margin:0 0 6px; }
.chart{ width:100%; height:240px; color:var(--blue); }
.axis{ stroke:var(--line); stroke-width:1; }
.muted{ color:var(--muted) !important; }
.donut-center text{ fill:#000 !important; }

/* 彙總表（沿用報表風格） */
.card.table{ padding:0; overflow:hidden; }
.card.table .h2{
  font-weight:900; padding:14px; margin:0; border-bottom:1px solid var(--line);
  background:linear-gradient(0deg,#fff, #fff), linear-gradient(#f8fafc,#f8fafc);
}
.table .thead, .table .row{
  display:grid; align-items:center; gap:8px; padding:10px 12px;
  grid-template-columns:1.2fr 120px 160px 120px;
}
.table .thead{
  background:#f8fafc; font-weight:800; border-bottom:1px solid var(--line);
}
.table .row{
  border-bottom:1px solid #eef2f6; background:#fff;
}
.table .row:hover{ background:#fcfffd; }
.mono{ font-family: ui-monospace, Menlo, Consolas, monospace; }
</style>
