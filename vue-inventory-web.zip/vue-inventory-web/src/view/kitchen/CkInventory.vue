﻿  <template>
    <section>
      <!-- 工具列 -->
      <div class="toolbar">
        <label class="row">
          <span>倉別：</span>
          <select v-model="storeId" class="input">
            <option v-for="s in stores" :key="s.id" :value="s.id">{{ s.name }}</option>
          </select>
        </label>

        <input class="input grow" v-model.trim="q" placeholder="搜尋食材 / SKU / 標籤" />

        <label class="row">
          <span>排序：</span>
          <select v-model="sortBy" class="input">
            <option value="sku">SKU</option>
            <option value="name">名稱</option>
            <option value="qty">庫存量</option>
            <option value="exp">最近效期</option>
          </select>
        </label>
        <button class="btn ghost" @click="asc = !asc">{{ asc ? '▲ 升冪' : '▼ 降冪' }}</button>

        <div class="spacer"></div>
        <button class="btn" @click="openCreate=true">＋ 新增食材</button>
        <button class="btn ghost" @click="exportCSV">匯出 CSV</button>
        <button class="btn ghost" @click="exportJSON">匯出 JSON</button>
      </div>

      <!-- KPI 卡片 -->
      <div class="cards">
        <div class="card stat"><div class="label">品項數</div><div class="value">{{ filtered.length }}</div></div>
        <div class="card stat"><div class="label">總庫存</div><div class="value">{{ totalQty }}</div></div>
        <div class="card stat"><div class="label">近7天到期</div><div class="value warn">{{ expiringSoon }}</div></div>
      </div>

      <!-- 明細（與報表相同 table 外觀） -->
      <div class="card table">
        <div class="h2">庫存清單</div>
        <div class="thead">
          <div class="c sku">SKU</div>
          <div class="c name">名稱</div>
          <div class="c qty">庫存</div>
          <div class="c unit">單位</div>
          <div class="c tags">標籤</div>
          <div class="c exp">最近效期</div>
          <div class="c act">操作</div>
        </div>

        <div class="row" v-for="it in sorted" :key="it.id">
          <div class="c sku mono">{{ it.sku }}</div>
          <div class="c name">{{ it.name }}</div>
          <div class="c qty"><b>{{ it.qty }}</b></div>
          <div class="c unit">{{ it.unit }}</div>
          <div class="c tags">
            <span v-for="t in it.tags" :key="t" class="tag">#{{ t }}</span>
          </div>
          <div class="c exp" :class="{danger: daysLeft(it.exp)<=3}">
            {{ it.exp }}
            <small class="muted">（{{ daysLeft(it.exp) }} 天<span v-if="new Date(it.exp) < new Date()">，已過期</span>）</small>
          </div>
          <div class="c act">
            <button class="icon small" title="入庫" @click="adjust(it, +1)">＋</button>
            <button class="icon small" title="出庫" @click="adjust(it, -1)">－</button>
            <button class="icon small" title="編輯" @click="edit(it)">✎</button>
            <button class="icon small danger" title="刪除" @click="remove(it.id)">🗑</button>
          </div>
        </div>
      </div>

      <!-- 建立 / 編輯 -->
      <div v-if="openCreate || curr" class="modal">
        <div class="panel">
          <div class="h2">{{ curr ? '編輯食材' : '新增食材' }}</div>
          <label>名稱<input class="input" v-model="form.name" /></label>
          <label>SKU<input class="input mono" v-model="form.sku" /></label>
          <div class="grid2">
            <label>庫存<input type="number" class="input" v-model.number="form.qty" /></label>
            <label>單位<input class="input" v-model="form.unit" placeholder="kg / 包 / 箱" /></label>
          </div>
          <label>標籤（逗號分隔）<input class="input" v-model="form.tagsRaw" placeholder="蔬菜,冷藏,有機" /></label>
          <label>最近效期<input type="date" class="input" v-model="form.exp" /></label>

          <div class="actions end">
            <button class="btn ghost" @click="closeModal">取消</button>
            <button class="btn" @click="save">儲存</button>
          </div>
        </div>
      </div>
    </section>
  </template>

  <script setup>
  import { computed, reactive, ref, watch } from 'vue'

  const stores = [{id:'CK', name:'中央廚房'},{id:'FZ', name:'冷凍庫'},{id:'DR', name:'乾貨區'}]
  const storeId = ref(localStorage.getItem('ck_storeId') || 'CK')
  const q = ref('')
  const sortBy = ref(localStorage.getItem('ck_sortBy') || 'name')
  const asc = ref(localStorage.getItem('ck_asc') ? localStorage.getItem('ck_asc')==='true' : true)

  watch([storeId, sortBy, asc], ([s, sb, a])=>{
    localStorage.setItem('ck_storeId', s)
    localStorage.setItem('ck_sortBy', sb)
    localStorage.setItem('ck_asc', String(a))
  })

  const items = ref([
    {id:1, store:'CK', sku:'C-0001', name:'洋蔥', unit:'顆', qty:120, tags:['蔬菜','常溫'], exp: nextDate(14)},
    {id:2, store:'CK', sku:'C-0002', name:'牛番茄', unit:'顆', qty:60,  tags:['蔬菜','冷藏'], exp: nextDate(5)},
    {id:3, store:'FZ', sku:'F-0101', name:'雞腿排', unit:'包', qty:32,  tags:['肉品','冷凍'], exp: nextDate(90)},
    {id:4, store:'DR', sku:'D-2201', name:'蠔油', unit:'瓶', qty:18,  tags:['調味','乾貨'], exp: nextDate(365)},
  ])

  const openCreate = ref(false)
  const curr = ref(null)
  const form = reactive({ name:'', sku:'', qty:0, unit:'', tagsRaw:'', exp:'' })

  const filtered = computed(() =>
    items.value.filter(it =>
      it.store===storeId.value &&
      (it.name+it.sku+it.tags.join(',')).toLowerCase().includes(q.value.toLowerCase())
    )
  )

  const sorted = computed(() => {
    const key = sortBy.value
    const list = [...filtered.value].sort((a,b)=>{
      const A = key==='exp' ? new Date(a.exp) : a[key]
      const B = key==='exp' ? new Date(b.exp) : b[key]
      if (A===B) return 0
      return (A>B?1:-1) * (asc.value?1:-1)
    })
    return list
  })

  const totalQty = computed(()=> filtered.value.reduce((s,i)=>s+i.qty,0))
  const expiringSoon = computed(()=> filtered.value.filter(i=>daysLeft(i.exp)<=7).length)

  function nextDate(d){ const dt=new Date(); dt.setDate(dt.getDate()+d); return dt.toISOString().slice(0,10) }
  function daysLeft(iso){ const diff=(new Date(iso)-new Date())/(1000*3600*24); return Math.max(0, Math.ceil(diff)) }

  function adjust(it, delta){ it.qty = Math.max(0, it.qty + delta) }
  function edit(it){
    curr.value = it
    Object.assign(form, { name:it.name, sku:it.sku, qty:it.qty, unit:it.unit, tagsRaw: it.tags.join(','), exp:it.exp })
  }
  function remove(id){ if(confirm('確定刪除？')) items.value = items.value.filter(i=>i.id!==id) }
  function closeModal(){ openCreate.value=false; curr.value=null; resetForm() }
  function resetForm(){ Object.assign(form,{name:'',sku:'',qty:0,unit:'',tagsRaw:'',exp:''}) }
  function save(){
    const payload = {
      name: form.name.trim(), sku: form.sku.trim(), qty: Number(form.qty||0),
      unit: form.unit.trim(), tags: form.tagsRaw.split(',').map(s=>s.trim()).filter(Boolean),
      exp: form.exp || nextDate(30), store: storeId.value
    }
    if (!payload.name || !payload.sku) { alert('名稱與 SKU 必填'); return }
    if (!curr.value && items.value.some(i=>i.sku===payload.sku && i.store===payload.store)) { alert('此倉別已存在相同 SKU'); return }
    if(curr.value) Object.assign(curr.value, payload); else items.value.push({ id:Date.now(), ...payload })
    closeModal()
  }
  function exportCSV(){
    const header = ['SKU','名稱','庫存','單位','標籤','效期']
    const rows = sorted.value.map(i=>[i.sku,i.name,i.qty,i.unit,i.tags.join('|'),i.exp].join(','))
    const content = '\uFEFF' + [header.join(','), ...rows].join('\n') // Excel 安心
    download('ck-inventory.csv', content)
  }
  function exportJSON(){ download('ck-inventory.json', JSON.stringify(sorted.value, null, 2)) }
  function download(name, content){
    const blob = new Blob([content], {type:'text/plain;charset=utf-8'})
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click()
    URL.revokeObjectURL(a.href)
  }
  </script>

<style scoped>
/* ===== 主題變數（與其它頁一致） ===== */
:root{
  --bg:#f6faf8;
  --card:#fff;
  --text:#000;          /* 全站黑字 */
  --muted:#2f3a48;      /* 次要字也偏黑 */
  --line:#e5e7eb;

  --primary:#28c7a5;    /* 薄荷綠主色 */
  --primary-weak:#e6fbf6;
  --blue:#2563eb;
  --blue-weak:#e8f0ff;

  --shadow:0 8px 24px rgba(15,23,42,.08);
  --radius-lg:16px;
  --radius-md:12px;
}

/* 全域：黑字 + 平滑字型 */
section, section *{ color:var(--text) !important; -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; }
::placeholder{ color:#333 !important; }
section{ background:var(--bg); }

/* ===== 工具列 ===== */
.toolbar{
  display:flex; gap:12px; align-items:center; flex-wrap:wrap; margin-bottom:12px;
  padding:12px 14px; background:var(--card); border:1px solid var(--line);
  border-radius:var(--radius-lg); box-shadow:var(--shadow);
}
.row{ display:flex; gap:8px; align-items:center; }
.spacer{ flex:1; }

/* 控件與按鈕 */
.input, select, .btn{
  border:1px solid var(--line); background:#fff; border-radius:12px;
  height:34px; padding:0 10px; font-size:14px; max-width:100%;
}
.input.grow{ flex:1; }
.btn{
  font-weight:800; color:#000 !important;
  background:var(--primary); box-shadow:0 4px 12px rgba(40,199,165,.15);
}
.btn.ghost{ background:#fff; box-shadow:none; }
.btn:hover{ filter:brightness(1.02); }
.btn:active{ transform:translateY(1px); }

/* ===== KPI 卡片 ===== */
.cards{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin:12px 0; }
.card{
  background:var(--card); border:1px solid var(--line); border-radius:var(--radius-lg);
  padding:14px; box-shadow:var(--shadow); min-width:0;
}
.stat .label{ color:var(--muted) !important; font-size:.9rem; }
.stat .value{ font-size:1.5rem; font-weight:900; }
.stat .value.warn{ color:#b91c1c; }

/* ===== 清單表格（grid 表頭+列） ===== */
.card.table{ padding:0; overflow:hidden; }
.card.table .h2{
  font-weight:900; padding:14px; margin:0; border-bottom:1px solid var(--line);
  background:linear-gradient(0deg,#fff, #fff), linear-gradient(#f8fafc,#f8fafc);
}
.thead, .row{
  display:grid; align-items:center; gap:8px; padding:10px 12px;
  grid-template-columns:130px 1.2fr 100px 90px 1.1fr 160px 160px;
}
.thead{
  background:#f8fafc; font-weight:800; border-bottom:1px solid var(--line);
}
.row{
  border-bottom:1px solid #eef2f6; background:#fff;
}
.row:hover{ background:#fcfffd; }

/* 欄位樣式 */
.tag{
  display:inline-flex; align-items:center; gap:6px;
  padding:.14rem .5rem; border:1px solid var(--line);
  border-radius:999px; background:#fff; font-size:.82rem; font-weight:700;
  margin:2px 6px 2px 0;
}
.c.qty b{ font-weight:900; }
.c.exp.danger{ color:#b91c1c; }
.muted{ color:var(--muted) !important; }
.mono{ font-family: ui-monospace, Menlo, Consolas, monospace; }

/* 操作按鈕（小型 icon 風） */
.icon.small{
  border:1px solid var(--line); background:#fff; border-radius:10px;
  padding:4px 8px; cursor:pointer; margin-right:6px; height:30px;
  display:inline-flex; align-items:center; justify-content:center;
}
.icon.small:hover{ box-shadow:0 2px 8px rgba(15,23,42,.12); }
.icon.small.danger{ border-color:#fecaca; }

/* ===== Modal（建立/編輯） ===== */
.modal{
  position:fixed; inset:0; background:rgba(2,6,23,.36);
  display:grid; place-items:center; z-index:30;
}
.panel{
  width:min(640px,92vw); background:#fff; border:1px solid var(--line); border-radius:20px;
  box-shadow:var(--shadow); padding:16px; display:grid; gap:10px;
}
.panel .h2{ font-weight:900; margin:2px 0 6px; }
.grid2{ display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.actions.end{ display:flex; justify-content:flex-end; gap:10px; margin-top:6px; }

/* ===== RWD ===== */
@media (max-width: 900px){
  .cards{ grid-template-columns:1fr; }
  .thead, .row{
    grid-template-columns:100px 1fr 80px 70px 1fr 120px 120px;
  }
}
</style>

