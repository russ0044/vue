﻿<template>
  <section>
    <!-- 工具列 -->
    <div class="toolbar">
      <label class="row">
        <span>日期：</span>
        <input type="date" class="input" v-model="selDate"/>
      </label>
      <label class="row">
        <span>車次：</span>
        <select class="input" v-model="routeId">
          <option v-for="r in routes" :key="r.id" :value="r.id">{{ r.name }}</option>
        </select>
      </label>
      <div class="spacer"></div>
      <button class="btn" @click="optimize()">自動排程</button>
      <button class="btn ghost" @click="exportStops">匯出站點</button>
    </div>

    <div class="grid">
      <!-- 左：待配送訂單 -->
      <div class="card">
        <div class="h2">未指派（{{ unassigned.length }}）</div>
        <div class="box">
          <div v-for="o in unassigned" :key="o.id" class="ticket">
            <div class="no mono">{{ o.no }}</div>
            <div class="title">{{ o.customer }}</div>
            <div class="muted">{{ o.addr }}</div>
            <div class="tags">
              <span class="tag" v-for="it in o.items" :key="it.name">{{ it.name }}×{{ it.qty }}</span>
            </div>
            <button class="btn tiny" @click="assign(o.id, routeId)">指派到 {{ currentRoute?.name }}</button>
          </div>
        </div>
      </div>

      <!-- 右：車次站點 -->
      <div class="card">
        <div class="h2">路線站點 — {{ currentRoute?.name }}</div>
        <ol class="stops">
          <li v-for="(s, i) in stopsByRoute" :key="s.id" class="stop">
            <div class="head">
              <b>{{ i+1 }}. {{ s.customer }}</b>
              <span class="muted">{{ s.time }}</span>
            </div>
            <div class="muted">{{ s.addr }}</div>
            <div class="tags">
              <span class="tag" v-for="it in s.items" :key="it.name">{{ it.name }}×{{ it.qty }}</span>
            </div>
            <div class="btns">
              <button class="icon small" title="上移" @click="move(i,-1)">↑</button>
              <button class="icon small" title="下移" @click="move(i,1)">↓</button>
              <button class="icon small danger" title="移除" @click="unassign(s.id)">🗑</button>
              <button class="icon small" title="完成" @click="complete(s)">✔</button>
            </div>
          </li>
        </ol>
      </div>
    </div>

    <!-- 地圖占位（可換成真正地圖） -->
    <div class="map">
      <div class="mapbox">
        <div class="h2">路線地圖（示意）</div>
        <svg viewBox="0 0 600 240" class="svg">
          <polyline :points="polylinePoints" fill="none" stroke="currentColor" stroke-width="2" />
          <g v-for="(s,i) in stopsByRoute" :key="s.id">
            <circle :cx="40 + i* (520/Math.max(1,stopsByRoute.length-1))" :cy="120+ Math.sin(i)*30" r="6"/>
            <text :x="40 + i* (520/Math.max(1,stopsByRoute.length-1))" :y="120+ Math.sin(i)*30 - 10" text-anchor="middle" font-size="10">{{ i+1 }}</text>
          </g>
        </svg>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, ref } from 'vue'

const selDate = ref(today())
const routes = [{id:'A',name:'A 車'},{id:'B',name:'B 車'}]
const routeId = ref('A')

const orders = ref([
  {id:1,no:'CK-250010',customer:'A 門市',addr:'台中市西屯區市政北一路 99 號',items:[{name:'雞腿',qty:10},{name:'洋蔥',qty:20}], time:'09:30', route:null},
  {id:2,no:'CK-250011',customer:'B 門市',addr:'台中市南屯區公益路二段 88 號',items:[{name:'番茄',qty:15}], time:'10:10', route:'A'},
  {id:3,no:'CK-250012',customer:'C 門市',addr:'台中市北屯區文心路四段 100 號',items:[{name:'蠔油',qty:3}], time:'11:00', route:null},
])

const currentRoute = computed(()=> routes.find(r=>r.id===routeId.value))
const unassigned = computed(()=> orders.value.filter(o=>!o.route))
const stopsByRoute = computed(()=> orders.value.filter(o=>o.route===routeId.value))

function assign(id, route){ const o = orders.value.find(x=>x.id===id); if(o) o.route = route }
function unassign(id){ const o = orders.value.find(x=>x.id===id); if(o) o.route = null }
function move(i, d){
  const list = stopsByRoute.value
  const from = orders.value.findIndex(o=>o.id===list[i].id)
  const to = orders.value.findIndex(o=>o.id===list[i+d]?.id)
  if(to<0) return
  const tmp = orders.value[from]; orders.value[from] = orders.value[to]; orders.value[to] = tmp
}
function complete(s){ alert(`完成配送：${s.customer}`) }

function exportStops(){
  const header = ['序','客戶','地址','到站時間','品項']
  const rows = stopsByRoute.value.map((s,i)=>[i+1,s.customer,s.addr,s.time,s.items.map(it=>`${it.name}×${it.qty}`).join('|')].join(','))
  download(`route-${routeId.value}-${selDate.value}.csv`, [header.join(','),...rows].join('\n'))
}
function download(name, content){
  const blob = new Blob([content], {type:'text/plain;charset=utf-8'})
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click()
  URL.revokeObjectURL(a.href)
}
function today(){ return new Date().toISOString().slice(0,10) }

const polylinePoints = computed(()=>{
  const n = Math.max(1, stopsByRoute.value.length-1)
  const pts = stopsByRoute.value.map((_,i)=>[40 + i*(520/n), 120+Math.sin(i)*30])
  return pts.map(p=>p.join(',')).join(' ')
})
</script>

<style scoped>
/* ===== 主題變數（與前面頁面一致） ===== */
:root{
  --bg:#f6faf8;
  --card:#fff;
  --text:#000;          /* 全站黑字 */
  --muted:#2f3a48;      /* 次要字也偏黑，對比佳 */
  --line:#e5e7eb;

  --primary:#28c7a5;    /* 薄荷綠主色 */
  --primary-weak:#e6fbf6;
  --blue:#2563eb;
  --blue-weak:#e8f0ff;

  --shadow:0 8px 24px rgba(15,23,42,.08);
  --radius-lg:16px;
  --radius-md:12px;
  --radius-sm:10px;
}

/* 全域：黑字 + 反鋸齒 */
section, section *{ color:var(--text) !important; -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; }
::placeholder{ color:#333 !important; }
section{ background:var(--bg); }

/* ===== 工具列 ===== */
.toolbar{
  display:flex; gap:12px; align-items:center; flex-wrap:wrap;
  margin-bottom:12px; padding:12px 14px;
  background:var(--card); border:1px solid var(--line);
  border-radius:var(--radius-lg); box-shadow:var(--shadow);
}
.row{ display:flex; gap:8px; align-items:center; }
.spacer{ flex:1; }
.muted{ color:var(--muted) !important; }

/* 控件 */
.input, select, .btn{
  border:1px solid var(--line); background:#fff; border-radius:12px;
  height:34px; padding:0 10px; font-size:14px; max-width:100%;
}
.btn{
  font-weight:800; color:#000 !important;
  background:var(--primary); box-shadow:0 4px 12px rgba(40,199,165,.15);
}
.btn.ghost{ background:#fff; box-shadow:none; }
.btn.sm{ height:30px; padding:0 10px; }
.btn.tiny{ height:28px; padding:0 10px; border-radius:999px; background:#fff; border:1px solid var(--line); box-shadow:none; }

/* ===== 兩欄網格 ===== */
.grid{ display:grid; grid-template-columns:1fr 1fr; gap:12px; }
@media (max-width:900px){ .grid{ grid-template-columns:1fr; } }

/* ===== 卡片 ===== */
.card{
  background:var(--card); border:1px solid var(--line);
  border-radius:var(--radius-lg); padding:14px; box-shadow:var(--shadow); min-width:0;
}
.h2{ font-weight:900; }

/* ===== 左側：未指派票卡 ===== */
.box{ display:grid; gap:10px; margin-top:8px; }
.ticket{
  border:1px solid var(--line); border-radius:var(--radius-md);
  padding:10px 12px; background:#f8fafc; transition: border-color .15s ease, box-shadow .15s ease, background .2s ease;
}
.ticket:hover{ background:#f1f5ff; border-color:#dbeafe; box-shadow:0 6px 16px rgba(30,64,175,.08); }
.ticket .no{ font-size:.9rem; color:#1f2937 !important; opacity:.9; }
.mono{ font-family: ui-monospace, Menlo, Consolas, monospace; }

.tags{ margin-top:6px; display:flex; flex-wrap:wrap; gap:6px; }
.tag{
  display:inline-flex; align-items:center; gap:6px;
  padding:.14rem .5rem; border:1px solid var(--line);
  border-radius:999px; background:#fff; font-size:.82rem; font-weight:700;
}

/* ===== 右側：站點清單 ===== */
.stops{ list-style:none; display:grid; gap:10px; margin:8px 0 0; padding:0; }
.stop{
  border:1px solid var(--line); border-radius:var(--radius-md);
  padding:10px 12px; background:#f8fafc; transition: border-color .15s ease, box-shadow .15s ease, background .2s ease;
}
.stop:hover{ background:#eef4ff; border-color:#bfdbfe; }
.stop .head{ display:flex; justify-content:space-between; align-items:center; gap:8px; }
.stop .head b{ font-weight:900; }
.btns{ margin-top:8px; display:flex; gap:6px; }
.icon.small{
  border:1px solid var(--line); background:#fff; border-radius:10px;
  padding:4px 8px; cursor:pointer; height:30px; display:inline-flex; align-items:center; justify-content:center;
}
.icon.small:hover{ box-shadow:0 2px 8px rgba(15,23,42,.12); }
.icon.small.danger{ border-color:#fecaca; }

/* ===== 地圖區 ===== */
.map{ margin-top:12px; }
.mapbox{
  background:#fff; border:1px solid var(--line); border-radius:var(--radius-lg);
  padding:12px 14px; box-shadow:var(--shadow);
}
.svg{
  width:100%; height:220px; color:var(--blue);
  /* 讓線條更銳利 */
  shape-rendering:geometricPrecision; text-rendering:geometricPrecision;
}
.svg polyline{ filter: drop-shadow(0 1px 0 rgba(0,0,0,.05)); }
.svg circle{ fill:#fff; stroke:var(--blue); stroke-width:2; }

/* ===== 小細節 ===== */
.tag + .tag{ margin-left:0; }   /* 我們用 gap 控制間距 */
</style>


