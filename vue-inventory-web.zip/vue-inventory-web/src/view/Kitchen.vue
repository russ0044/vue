<template>
  <div class="screen">
    <!-- 頂部列 -->
    <header class="topbar">
      <div class="brand">
        <div class="avatar">🍳</div>
        <div>
          <div class="title">中央廚房</div>
          <div class="sub">ID: CK-0001</div>
        </div>
      </div>

      <div class="actions">
        <button class="icon-btn" title="系統設定" @click="goSettings">⚙</button>
        <RoleBadge v-if="hasRoleBadge" />
        <span v-else class="role-pill">廚房</span>
        <button class="logout" @click="onLogout">登出</button>
      </div>
    </header>

    <!-- 主體 -->
    <div class="body">
      <aside class="sidebar">
        <RouterLink :to="{ name:'ck-inventory' }" class="navbtn" :class="{active: route.name==='ck-inventory'}">食材庫存</RouterLink>
        <RouterLink :to="{ name:'ck-orders' }"    class="navbtn" :class="{active: route.name==='ck-orders'}">訂單管理</RouterLink>
        <RouterLink :to="{ name:'ck-delivery' }"  class="navbtn" :class="{active: route.name==='ck-delivery'}">配送安排</RouterLink>
        <RouterLink :to="{ name:'ck-reports' }"   class="navbtn" :class="{active: route.name==='ck-reports'}">報表分析</RouterLink>
      </aside>

      <main class="content">
        <RouterView />
      </main>
    </div>
  </div>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router'
import { useAuth } from '@/store/auth'
import RoleBadge from '@/components/RoleBadge.vue'

const hasRoleBadge = true

const route = useRoute()
const router = useRouter()
const { logout } = useAuth()

function goSettings(){ router.push('/settings') }
function onLogout(){ logout(); router.replace('/login') }
</script>

<style scoped>
.screen{max-width:1180px;margin:16px auto;background:#f8fafc;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,.06);overflow:hidden}
.topbar{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;background:#fff;border-bottom:1px solid #e5e7eb}
.brand{display:flex;gap:12px;align-items:center}
.avatar{width:42px;height:42px;border-radius:50%;background:#e5e7eb;display:grid;place-items:center;font-size:18px}
.title{font-weight:700}
.sub{font-size:.85rem;color:#64748b}
.actions{display:flex;align-items:center;gap:12px}
.icon-btn{background:#fff;border:1px solid #d1d5db;border-radius:50%;width:36px;height:36px;cursor:pointer;font-size:18px;line-height:1;display:flex;align-items:center;justify-content:center}
.icon-btn:hover{background:#f1f5f9}
.role-pill{padding:.28rem .6rem;border-radius:999px;background:#eef2ff;color:#1d4ed8;border:1px solid #dbeafe;font-weight:600}
.logout{background:#ef4444;color:#fff;border:none;padding:6px 12px;border-radius:8px;cursor:pointer;font-size:14px}
.logout:hover{background:#dc2626}
.body{display:flex;min-height:560px}
.sidebar{width:260px;padding:16px;background:#fff;border-right:1px solid #e5e7eb;display:flex;flex-direction:column;gap:12px}
.navbtn{padding:14px 16px;border:1px solid #d1d5db;border-radius:14px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.03);text-align:center;cursor:pointer;color:inherit;text-decoration:none}
.navbtn:hover{transform:translateY(-1px);box-shadow:0 4px 14px rgba(0,0,0,.08)}
.navbtn.active{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.12)}
.content{flex:1;padding:18px}
</style>
