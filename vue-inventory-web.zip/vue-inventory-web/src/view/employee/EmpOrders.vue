<template>
  <section>
    <div class="main-head">
      <div class="h2">訂單情況</div>
      <div class="spacer"></div>
      <div style="display:flex;gap:6px;align-items:center">
        <label class="muted small">來源</label>
        <select v-model="dataSource.mode" class="input sm" @change="onModeChanged">
          <option value="local">Local（假資料）</option>
          <option value="firebase">Firebase（預留）</option>
        </select>
        <button class="btn ghost small" @click="exportJSON">匯出</button>
        <label class="btn ghost small file-btn">
          匯入 <input type="file" accept="application/json" @change="importJSON">
        </label>
      </div>
    </div>

    <div class="two-col">
      <aside class="side" :class="{open:drawerOpen}">
        <div class="side-head">
          <div style="display:flex;gap:8px;align-items:center">
            <label class="muted">日期</label>
            <input class="input" type="date" v-model="dateStr">
          </div>
          <div class="seg" style="margin-top:8px">
            <button :class="['segbtn', tab==='req' && 'active']" @click="tab='req'">請貨</button>
            <button :class="['segbtn', tab==='ord' && 'active']" @click="tab='ord'">訂單</button>
          </div>
          <div style="margin-top:8px">
            <button class="btn primary w100" @click="quickNew" v-can="'orders.create'">＋ 新增請貨</button>
          </div>
        </div>

        <div class="side-list" v-if="tab==='req'">
          <div class="side-item" v-for="r in reqList" :key="r.id" :class="{active: r.id===selectedId}" @click="selectLeft(r.id)">
            <div class="grow">
              <div style="font-weight:700">{{ r.date }}</div>
              <div class="muted small">品項：{{ r.items.length }}</div>
            </div>
            <div class="badge" :class="r.status">{{ r.status==='pending'?'待送出':'已送出' }}</div>
          </div>
          <p v-if="!reqList.length" class="muted center">沒有請貨單</p>
        </div>

        <div class="side-list" v-else>
          <div class="side-item" v-for="o in ordList" :key="o.id" :class="{active: o.id===selectedId}" @click="selectLeft(o.id)">
            <div class="grow">
              <div style="font-weight:700">{{ o.date }}</div>
              <div class="muted small">品項：{{ o.items.length }}</div>
            </div>
            <div class="badge primary">訂單</div>
          </div>
          <p v-if="!ordList.length" class="muted center">沒有訂單</p>
        </div>
      </aside>

      <transition name="fade"><div v-if="drawerOpen" class="backdrop" @click="drawerOpen=false"></div></transition>

      <main class="card">
        <div class="main-head">
          <div class="h2">{{ tab==='req'?'請貨單':'訂單' }}</div>
          <div class="spacer"></div>
          <template v-if="tab==='req' && currentReq">
            <button class="btn" v-can="'orders.create'" @click="addLine">新增品項</button>
            <button class="btn" v-can="'orders.create'" @click="removeZero">移除 0 件</button>
            <button class="btn primary" v-can="'orders.create'" @click="submitRequest">送出請貨</button>
          </template>
          <template v-else-if="tab==='ord' && currentOrd">
            <button class="btn" @click="print">列印</button>
          </template>
        </div>

        <!-- 請貨單 -->
        <template v-if="tab==='req'">
          <div v-if="!currentReq" class="center muted" style="padding:24px">📄 請從左側選取或新增請貨單</div>
          <div v-else>
            <div style="display:flex;justify-content:space-between;padding:10px 12px;border-bottom:1px dashed var(--border)">
              <div>門市：{{ scope.storeName }}</div>
              <div>日期：<input class="input" type="date" v-model="currentReq.date" @change="saveDB"></div>
            </div>
            <div class="table" style="margin-top:10px">
              <div class="th">
                <div style="width:200px">品名</div>
                <div style="width:90px">單位</div>
                <div style="width:120px">數量</div>
                <div class="spacer">備註</div>
                <div style="width:60px"></div>
              </div>
              <div class="tr" v-for="(it,idx) in currentReq.items" :key="it.key">
                <div style="width:200px"><input class="input w100" v-model.trim="it.name" placeholder="品名"></div>
                <div style="width:90px"><input class="input w100" v-model.trim="it.unit" placeholder="單位"></div>
                <div style="width:120px"><input class="input w100" type="number" min="0" v-model.number="it.qty"></div>
                <div class="spacer"><input class="input w100" v-model.trim="it.note" placeholder="備註…"></div>
                <div style="width:60px"><button class="btn ghost small" v-can="'orders.create'" @click="delLine(idx)">刪除</button></div>
              </div>
            </div>
          </div>
        </template>

        <!-- 訂單 -->
        <template v-else>
          <div v-if="!currentOrd" class="center muted" style="padding:24px">📄 請從左側選擇訂單</div>
          <div v-else>
            <div style="display:flex;justify-content:space-between;padding:10px 12px;border-bottom:1px dashed var(--border)">
              <div>門市：{{ scope.storeName }}</div>
              <div>日期：{{ currentOrd.date }}</div>
            </div>
            <div class="table" style="margin-top:10px">
              <div class="th">
                <div style="width:200px">品名</div>
                <div style="width:90px">單位</div>
                <div style="width:120px">數量</div>
                <div class="spacer">備註</div>
              </div>
              <div class="tr" v-for="it in currentOrd.items" :key="it.key">
                <div style="width:200px">{{ it.name }}</div>
                <div style="width:90px">{{ it.unit }}</div>
                <div style="width:120px">{{ it.qty }}</div>
                <div class="spacer">{{ it.note || '—' }}</div>
              </div>
            </div>
          </div>
        </template>

      </main>
    </div>

    <transition name="fade"><div v-if="toast" class="toast">{{ toast }}</div></transition>
  </section>
</template>

<script setup>
import { reactive, ref, computed, onMounted } from 'vue'
import { useScope } from '@/store/scope'

const scope = useScope()
const rid = ()=> 'id-' + Math.random().toString(36).slice(2,10)
const today = ()=> new Date().toISOString().slice(0,10)

const toast = ref(''); const tip = (m)=>{ toast.value=m; setTimeout(()=>toast.value='',1200) }
const dataSource = reactive({ mode: localStorage.getItem('emp-ord-mode') || 'local', async fetchAll(){ loadDB() } })
function onModeChanged(){ localStorage.setItem('emp-ord-mode', dataSource.mode); tip('已切換來源（示意）') }

const db = reactive({ req:[], ord:[] })
function saveDB(){ localStorage.setItem(`emp-orders-${scope.storeId}`, JSON.stringify(db)) }
function loadDB(){
  const raw = localStorage.getItem(`emp-orders-${scope.storeId}`)
  if (raw) { try{ Object.assign(db, JSON.parse(raw)); return }catch{ localStorage.removeItem(`emp-orders-${scope.storeId}`) } }
  db.req = [{ id:rid(), storeId:scope.storeId, date: today(), status:'pending',
    items:[{key:rid(),name:'大力士雞腿',unit:'份',qty:20,note:''},{key:rid(),name:'豬骨高湯',unit:'桶',qty:1,note:''}]
  }]
  db.ord = [{ id:rid(), storeId:scope.storeId, date: today(),
    items:[{key:rid(),name:'新鮮雞腿',unit:'份',qty:30,note:''},{key:rid(),name:'米漿醬油',unit:'瓶',qty:2,note:''}]
  }]
  saveDB()
}

const drawerOpen = ref(false)
const tab = ref('req')
const dateStr = ref(today())
const selectedId = ref(null)

const reqList = computed(()=> db.req.filter(x=>x.storeId===scope.storeId && x.date===dateStr.value))
const ordList = computed(()=> db.ord.filter(x=>x.storeId===scope.storeId && x.date===dateStr.value))
const currentReq = computed(()=> db.req.find(x=>x.id===selectedId.value) || null)
const currentOrd = computed(()=> db.ord.find(x=>x.id===selectedId.value) || null)

function selectLeft(id){ selectedId.value = id; drawerOpen.value=false }
function quickNew(){
  const r = { id:rid(), storeId:scope.storeId, date:dateStr.value, status:'pending', items:[] }
  db.req.unshift(r); selectedId.value = r.id; tab.value='req'; saveDB(); tip('已新增請貨單')
}
function addLine(){ currentReq.value?.items.push({ key:rid(), name:'', unit:'份', qty:0, note:'' }) }
function delLine(i){ currentReq.value?.items.splice(i,1) }
function removeZero(){ if (!currentReq.value) return; currentReq.value.items = currentReq.value.items.filter(it => (+it.qty||0) > 0) }
function submitRequest(){
  const r = currentReq.value; if (!r) return
  if (!r.items.length) return tip('請先新增品項')
  r.status = 'submitted'
  const o = { id:rid(), storeId:r.storeId, date:r.date, items: r.items.map(it=>({ ...it, key:rid() })) }
  db.ord.unshift(o); selectedId.value = o.id; tab.value='ord'
  saveDB(); tip('已送出請貨並建立訂單')
}
function print(){ window.print() }

function exportJSON(){
  const blob = new Blob([JSON.stringify(db,null,2)],{type:'application/json'})
  const url = URL.createObjectURL(blob); const a=document.createElement('a')
  a.href=url; a.download=`emp-orders-${scope.storeId}.json`; a.click(); URL.revokeObjectURL(url)
}
function importJSON(e){
  const f = e.target.files?.[0]; if(!f) return
  const reader = new FileReader()
  reader.onload=()=>{
    try{
      const obj = JSON.parse(String(reader.result))
      if (!obj || !Array.isArray(obj.req) || !Array.isArray(obj.ord)) throw new Error()
      db.req = obj.req; db.ord = obj.ord; saveDB(); tip('已匯入資料')
    }catch{ tip('匯入失敗：格式錯誤') }
  }
  reader.readAsText(f,'utf-8')
}
onMounted(()=> dataSource.fetchAll())

</script>
<style scoped>
/* ===== 主題變數（薄荷綠系） ===== */
:root{
  --bg:#f6faf8;
  --card:#fff;
  --text:#000;        /* 依需求：統一黑字 */
  --muted:#2f3a48;    /* 次要文字也偏黑，對比佳 */
  --line:#e5e7eb;

  --primary:#28c7a5;
  --primary-weak:#e6fbf6;

  --blue:#2563eb;
  --blue-weak:#e8f0ff;

  --ok:#10b981;
  --warn:#f59e0b;

  --shadow:0 8px 24px rgba(15,23,42,.08);
  --radius-lg:16px;
  --radius-md:12px;
}

/* 全域：黑字 + 反鋸齒 */
section, input, select, button, label, .muted, .small, .badge{
  color:#000 !important;
  -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;
}
::placeholder{ color:#333 !important; }

/* 背景 */
html,body{ background:var(--bg); }
section{ padding:12px; }

/* ===== 頁首工具列 ===== */
.main-head{
  display:flex; align-items:center; gap:10px;
  background:var(--card); border-radius:var(--radius-lg);
  padding:16px 18px; margin:0 16px 12px 16px; box-shadow:var(--shadow);
}
.h2{ font-size:18px; font-weight:800; }
.spacer{ flex:1; }

/* ===== 控件 ===== */
.input, select, button{
  height:34px; border:1px solid var(--line); background:#fff; border-radius:10px;
  padding:0 10px; font-size:14px; max-width:100%;
}
.input.sm{ height:30px; }
button.btn{
  background:var(--primary); color:#000 !important;    /* 黑字 */
  border:none; border-radius:12px; padding:0 14px; height:34px; font-weight:800;
  box-shadow:0 4px 14px rgba(40,199,165,.25);
}
button.btn.ghost{
  background:#fff; color:#000 !important; border:1px solid var(--line); box-shadow:none;
}
button.btn.primary{ background:var(--primary); }
button.btn.small{ height:30px; padding:0 10px; }

/* 匯入檔案整顆可點 */
.file-btn{ position:relative; overflow:hidden; }
.file-btn input[type="file"]{ position:absolute; inset:0; opacity:0; cursor:pointer; }

/* ===== 兩欄版面 ===== */
.two-col{
  display:grid; grid-template-columns: 360px minmax(0,1fr);
  gap:16px; padding:0 16px; align-items:start;
}
.two-col > *{ min-width:0; }

/* ===== 左側欄（支援行動抽屜） ===== */
.side{
  background:var(--card); border-radius:var(--radius-lg); box-shadow:var(--shadow);
  padding:14px; overflow:hidden; display:flex; flex-direction:column;
  position:sticky; top:72px; align-self:start;
}
.side-head{ width:100%; }
.muted{ color:var(--muted) !important; }
.small{ font-size:12px; }

.seg{ display:flex; justify-content:center; gap:8px; margin:8px 0; }
.segbtn{
  padding:6px 10px; border-radius:999px; border:1px solid var(--line);
  background:#fff; cursor:pointer; font-size:14px; font-weight:700;
}
.segbtn.active{ background:var(--blue-weak); border-color:var(--blue); color:#000 !important; }

.side-list{
  width:100%; height:calc(100vh - 240px); overflow:auto; padding:6px 4px 10px;
}
.side-item{
  display:flex; align-items:center; justify-content:space-between; gap:8px;
  border:1px solid var(--line); border-radius:12px; background:#f9fafc;
  padding:10px 12px; margin-bottom:10px; transition:box-shadow .15s ease, border-color .15s ease, background .2s ease;
}
.side-item:hover{ background:#f1f5ff; border-color:#dbeafe; box-shadow:0 6px 16px rgba(30,64,175,.08); }
.side-item.active{ outline:2px solid #bfdbfe; background:#eef4ff; }
.side-item .grow{ flex:1 1 auto; min-width:0; }

/* 狀態章 */
.badge{ padding:3px 10px; border-radius:999px; font-size:12px; font-weight:800; white-space:nowrap; }
.badge.primary{ background:#e0f2fe; border:1px solid #bae6fd; }
.badge.pending{ background:#fff7ed; border:1px solid #fed7aa; }
.badge.submitted{ background:#ecfdf5; border:1px solid #a7f3d0; }

/* ===== 右側主卡 ===== */
main.card{
  background:var(--card); border-radius:var(--radius-lg); box-shadow:var(--shadow);
  padding:20px; min-width:0; overflow:hidden; display:flex; flex-direction:column;
}
main.card .main-head{ box-shadow:none; padding:0; margin:0 0 12px 0; background:transparent; }

/* 上方資訊列 */
.info-bar, [style*="border-bottom:1px dashed"]{
  border-bottom:1px dashed var(--line) !important;
}

/* ===== 表格（請貨/訂單共用） ===== */
.table{ width:100%; max-width:100%; overflow-x:auto; border-radius:12px; background:#fff; }
.th, .tr{
  display:flex; align-items:center; gap:8px; padding:10px 12px;
  border-bottom:1px solid #eef2f7; flex-wrap:wrap;
}
.th{
  font-weight:800; background:#f8fafc; border-radius:8px 8px 0 0;
}
.th > div, .tr > div{ min-width:0; }
.tr .spacer, .th .spacer{ flex:1 1 auto; min-width:120px; }

/* ===== 抽屜與遮罩（行動裝置） ===== */
.backdrop{ position:fixed; inset:0; background:rgba(2,6,23,.35); z-index:8; }
.only-mobile{ display:none; }

@media (max-width: 980px){
  .two-col{ grid-template-columns:1fr; }
  .side{
    position:fixed; z-index:9; inset:0 auto 0 0; width:88%;
    transform:translateX(-100%); transition:transform .22s ease; top:0;
  }
  .side.open{ transform:translateX(0); }
}

/* ===== 捲軸美化 ===== */
.side-list::-webkit-scrollbar{ width:10px; }
.side-list::-webkit-scrollbar-thumb{
  background:#e5e7eb; border-radius:999px; border:2px solid transparent; background-clip:content-box;
}
</style>
