<template>
  <section>
    <h2 class="section-title">配送情況</h2>

    <!-- 工具列 -->
    <div class="toolbar">
      <button class="btn" @click="shiftDate(-1)">← 前一天</button>
      <label class="row">
        <span>日期：</span>
        <input class="input" type="date" v-model="dateStr" />
      </label>
      <button class="btn" @click="shiftDate(1)">後一天 →</button>

      <label class="row">
        <span>狀態：</span>
        <select v-model="status" class="input">
          <option value="all">全部</option>
          <option value="preparing">準備中</option>
          <option value="shipping">運送中</option>
          <option value="arrived">已到店</option>
        </select>
      </label>

      <input class="input" style="min-width:200px" v-model.trim="q" placeholder="搜尋單號 / 品名" />

      <div class="spacer"></div>

      <div class="muted small row">
        <span>來源</span>
        <select v-model="dataSource.mode" class="input sm" @change="onModeChanged">
          <option value="local">Local（假資料）</option>
          <option value="firebase">Firebase（預留）</option>
        </select>
      </div>

      <button class="btn ghost small" @click="exportCSV">匯出 CSV</button>
      <button class="btn ghost small" @click="exportJSON">匯出 JSON</button>
      <label class="btn ghost small file-btn">匯入
        <input type="file" accept="application/json" @change="importJSON" />
      </label>

      <button class="btn" @click="openCreate">＋ 新增配送單</button>
    </div>

    <!-- 今日摘要 -->
    <div class="summary">
      <div>單數：<b>{{ list.length }}</b></div>
      <div>總品項數：<b>{{ totalItems }}</b></div>
      <div>已到店：<b>{{ arrivedCount }}</b>（{{ arrivedRate }}%）</div>
    </div>

    <!-- 主卡片 -->
    <div class="card">
      <table class="table">
        <thead>
          <tr>
            <th>配送單號</th>
            <th>日期</th>
            <th>品項數</th>
            <th>狀態</th>
            <th style="width:200px">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="d in list" :key="d.id"
              :class="{active: d.id===selectedId}"
              @click="selectRow(d.id)">
            <td>{{ d.no }}</td>
            <td>{{ d.date }}</td>
            <td>{{ d.items.length }}</td>
            <td>
              <span :class="['badge', badgeClass(d.status)]">{{ text(d.status) }}</span>
            </td>
            <td class="row">
              <button class="btn sm" :disabled="d.status==='arrived'" @click.stop="nextStage(d)">
                狀態前進
              </button>
              <button class="btn sm" @click.stop="openEdit(d)">編輯</button>
              <button class="btn sm ghost" @click.stop="removeDelivery(d)">刪除</button>
            </td>
          </tr>
          <tr v-if="!list.length">
            <td colspan="5" class="muted center">沒有配送單</td>
          </tr>
        </tbody>
      </table>

      <!-- 詳情（點列後展開） -->
      <div v-if="cur" class="detail">
        <div class="detail-head">
          <div>門市：{{ scope.storeName }}</div>
          <div>日期：{{ cur.date }}</div>
        </div>

        <div class="detail-meta">
          <div class="meta-title">配送單號：{{ cur.no }}</div>
          <div class="muted small">
            狀態：{{ text(cur.status) }}
            <template v-if="cur.status==='arrived' && cur.arrivedAt">
              ｜簽收時間：{{ cur.arrivedAt }}｜簽收人：{{ cur.receivedBy || '—' }}
            </template>
          </div>
        </div>

        <!-- 品項簽收（部分簽收） -->
        <div class="table slim">
          <div class="th">
            <div class="spacer">品名</div>
            <div class="w120">單位</div>
            <div class="w120">應到數</div>
            <div class="w160">實到數（可修改）</div>
          </div>
          <div class="tr" v-for="it in cur.items" :key="it.key">
            <div class="spacer">{{ it.name }}</div>
            <div class="w120">{{ it.unit }}</div>
            <div class="w120">{{ it.qty }}</div>
            <div class="w160">
              <input class="input sm" type="number" min="0"
                     v-model.number="it.recvQty"
                     @change="saveDB" />
            </div>
          </div>
        </div>

        <div class="detail-note">
          <div class="meta-title">備註</div>
          <div class="muted">{{ cur.note || '—' }}</div>
        </div>

        <div class="row" style="padding:12px; gap:8px">
          <button class="btn" :disabled="cur.status==='arrived'" @click="markArrived(cur)">
            簽收並標記為已到店
          </button>
          <button class="btn ghost" @click="exportOne(cur)">匯出此單（JSON）</button>
        </div>
      </div>
    </div>

    <!-- 建立/編輯表單 -->
    <div v-if="editor.show" class="drawer">
      <div class="drawer-head">
        <div class="h2">{{ editor.mode==='create' ? '新增配送單' : '編輯配送單' }}</div>
        <button class="btn ghost" @click="closeEditor">✕</button>
      </div>

      <div class="drawer-body">
        <div class="form-grid">
          <label>配送單號
            <input class="input" v-model.trim="editor.form.no" placeholder="DL-001" />
          </label>
          <label>日期
            <input class="input" type="date" v-model="editor.form.date" />
          </label>
          <label>狀態
            <select class="input" v-model="editor.form.status">
              <option value="preparing">準備中</option>
              <option value="shipping">運送中</option>
              <option value="arrived">已到店</option>
            </select>
          </label>
          <label class="col-span-3">備註
            <input class="input" v-model.trim="editor.form.note" placeholder="例如：低溫配送" />
          </label>
        </div>

        <div class="h3" style="margin-top:10px">品項</div>
        <div class="table slim">
          <div class="th">
            <div class="spacer">品名</div>
            <div class="w120">單位</div>
            <div class="w120">數量</div>
            <div class="w100 center">操作</div>
          </div>
          <div class="tr" v-for="(it, idx) in editor.form.items" :key="it.key">
            <div class="spacer">
              <input class="input sm" v-model.trim="it.name" placeholder="新鮮雞腿" />
            </div>
            <div class="w120">
              <input class="input sm" v-model.trim="it.unit" placeholder="份/公斤/桶" />
            </div>
            <div class="w120">
              <input class="input sm" type="number" min="0" v-model.number="it.qty" />
            </div>
            <div class="w100 center">
              <button class="btn sm ghost" @click="removeItem(idx)">刪除</button>
            </div>
          </div>
          <div class="tr">
            <div class="spacer">
              <input class="input sm" v-model.trim="draft.name" placeholder="品名" />
            </div>
            <div class="w120">
              <input class="input sm" v-model.trim="draft.unit" placeholder="單位" />
            </div>
            <div class="w120">
              <input class="input sm" type="number" min="0" v-model.number="draft.qty" placeholder="數量" />
            </div>
            <div class="w100 center">
              <button class="btn sm" @click="addItem">加入</button>
            </div>
          </div>
        </div>

        <div class="row" style="margin-top:12px; gap:8px">
          <button class="btn" @click="saveEditor">儲存</button>
          <button class="btn ghost" @click="closeEditor">取消</button>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { reactive, ref, computed, onMounted } from 'vue'
import { useScope } from '@/store/scope'

const scope = useScope()
const rid   = ()=>'id-'+Math.random().toString(36).slice(2,10)
const today = ()=> new Date().toISOString().slice(0,10)
const text  = s => s==='preparing' ? '準備中' : s==='shipping' ? '運送中' : '已到店'
const badgeClass = s => s==='arrived' ? 'badge-ok' : s==='shipping' ? 'badge-info' : 'badge-warn'

const dataSource = reactive({
  mode: localStorage.getItem('emp-delivery-mode') || 'local',
  async fetchAll(){ loadDB() }
})
function onModeChanged(){ localStorage.setItem('emp-delivery-mode', dataSource.mode) }

const db = reactive({ deliveries: [] })
function saveDB(){ localStorage.setItem(`emp-delivery-${scope.storeId}`, JSON.stringify(db)) }
function loadDB(){
  const raw = localStorage.getItem(`emp-delivery-${scope.storeId}`)
  if (raw){
    try{ Object.assign(db, JSON.parse(raw)); return }
    catch{ localStorage.removeItem(`emp-delivery-${scope.storeId}`) }
  }
  db.deliveries = [
    { id:rid(), storeId:scope.storeId, date:today(), no:'DL-'+rndNo(),
      status:'preparing', note:'', items:[
        {key:rid(),name:'新鮮雞腿',unit:'份',qty:30,recvQty:0},
        {key:rid(),name:'豬骨高湯',unit:'桶',qty:1,recvQty:0}
      ] },
    { id:rid(), storeId:scope.storeId, date:today(), no:'DL-'+rndNo(),
      status:'shipping', note:'低溫配送', items:[
        {key:rid(),name:'新鮮豬腿',unit:'公斤',qty:20,recvQty:0}
      ] },
  ]
  saveDB()
}
const rndNo = ()=> Math.floor(Math.random()*900+100)

const dateStr = ref(today())
const status  = ref('all')
const q = ref('')
const selectedId = ref(null)

const baseList = computed(()=> db.deliveries
  .filter(d => d.storeId===scope.storeId && d.date===dateStr.value)
  .filter(d => status.value==='all' ? true : d.status===status.value)
  .sort((a,b)=>{
    const order = {preparing:0, shipping:1, arrived:2}
    if (order[a.status]!==order[b.status]) return order[a.status]-order[b.status]
    return a.no.localeCompare(b.no)
  })
)

const list = computed(()=>{
  const kw = q.value.trim()
  if (!kw) return baseList.value
  const lower = kw.toLowerCase()
  return baseList.value.filter(d => {
    const hitNo = d.no.toLowerCase().includes(lower)
    const hitItem = d.items.some(it => String(it.name).toLowerCase().includes(lower))
    return hitNo || hitItem
  })
})

const cur = computed(()=> db.deliveries.find(d=> d.id===selectedId.value) || null)

const totalItems = computed(()=> list.value.reduce((s,d)=> s + d.items.length, 0))
const arrivedCount = computed(()=> list.value.filter(d=> d.status==='arrived').length)
const arrivedRate = computed(()=> list.value.length ? Math.round(arrivedCount.value*100/list.value.length) : 0)

function selectRow(id){ selectedId.value = id }
function nextStage(row){
  const target = row ?? cur.value
  if (!target) return
  target.status = target.status==='preparing' ? 'shipping' : 'arrived'
  if (target.status==='arrived' && !target.arrivedAt){
    target.arrivedAt = new Date().toLocaleString()
    target.receivedBy = scope.employeeName || '員工'
    // 預設：未填的 recvQty 用應到數補齊
    target.items.forEach(it => { if (it.recvQty==null) it.recvQty = it.qty })
  }
  saveDB()
}

function markArrived(row){
  const target = row ?? cur.value
  if (!target) return
  target.status = 'arrived'
  target.arrivedAt = new Date().toLocaleString()
  target.receivedBy = scope.employeeName || '員工'
  target.items.forEach(it => { if (it.recvQty==null) it.recvQty = it.qty })
  saveDB()
}

function exportJSON(){
  const blob = new Blob([JSON.stringify(db,null,2)],{type:'application/json'})
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `emp-delivery-${scope.storeId}.json`
  a.click()
  URL.revokeObjectURL(url)
}
function exportCSV(){
  const rows = [['no','date','status','item','unit','qty','recvQty','note']]
  db.deliveries
    .filter(d => d.storeId===scope.storeId && d.date===dateStr.value)
    .forEach(d => d.items.forEach(it => {
      rows.push([d.no,d.date,d.status,it.name,it.unit,it.qty,(it.recvQty ?? ''),d.note ?? ''])
    }))
  const csv = rows.map(r => r.map(x => `"${String(x).replaceAll('"','""')}"`).join(',')).join('\n')
  const blob = new Blob([csv],{type:'text/csv'})
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `emp-delivery-${scope.storeId}-${dateStr.value}.csv`
  a.click()
  URL.revokeObjectURL(url)
}
function exportOne(d){
  const blob = new Blob([JSON.stringify(d,null,2)],{type:'application/json'})
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${d.no}.json`
  a.click()
  URL.revokeObjectURL(url)
}
function importJSON(e){
  const f = e.target.files?.[0]; if(!f) return
  const reader = new FileReader()
  reader.onload = ()=>{
    try{
      const obj = JSON.parse(String(reader.result))
      if (!obj || !Array.isArray(obj.deliveries)) throw new Error()
      // 正規化 old data：補 recvQty 欄位
      obj.deliveries.forEach(d => d.items?.forEach(it => { if (it.recvQty==null) it.recvQty = 0 }))
      db.deliveries = obj.deliveries
      saveDB()
    }catch{/* ignore */}
  }
  reader.readAsText(f, 'utf-8')
}

function shiftDate(delta){
  const dt = new Date(dateStr.value)
  dt.setDate(dt.getDate()+delta)
  dateStr.value = dt.toISOString().slice(0,10)
}

// 編輯器（新增/編輯）
const editor = reactive({
  show:false,
  mode:'create', // 'create' | 'edit'
  id:null,
  form:{ no:'', date:today(), status:'preparing', note:'', items:[] }
})
const draft = reactive({ name:'', unit:'', qty:0 })

function openCreate(){
  editor.mode = 'create'
  editor.id = null
  editor.form = { no:`DL-${rndNo()}`, date:dateStr.value, status:'preparing', note:'', items:[] }
  draft.name=''; draft.unit=''; draft.qty=0
  editor.show = true
}
function openEdit(d){
  editor.mode = 'edit'
  editor.id = d.id
  // 深拷貝避免直接綁到原資料
  editor.form = JSON.parse(JSON.stringify(d))
  editor.show = true
}
function closeEditor(){ editor.show = false }

function addItem(){
  if (!draft.name || !draft.unit || !Number.isFinite(draft.qty)) return
  editor.form.items.push({ key:rid(), name:draft.name, unit:draft.unit, qty:Number(draft.qty), recvQty:0 })
  draft.name=''; draft.unit=''; draft.qty=0
}
function removeItem(idx){ editor.form.items.splice(idx,1) }

function saveEditor(){
  const f = editor.form
  if (!f.no || !f.date || !f.items.length) return
  if (editor.mode==='create'){
    db.deliveries.push({
      id:rid(), storeId:scope.storeId, ...f
    })
  }else{
    const idx = db.deliveries.findIndex(d=> d.id===editor.id)
    if (idx>=0) db.deliveries[idx] = { ...db.deliveries[idx], ...f }
    if (selectedId.value === editor.id) selectRow(editor.id) // 保持選取
  }
  saveDB()
  editor.show = false
}

function removeDelivery(d){
  if (!confirm(`刪除配送單 ${d.no}？`)) return
  const idx = db.deliveries.findIndex(x => x.id===d.id)
  if (idx>=0) db.deliveries.splice(idx,1)
  if (selectedId.value===d.id) selectedId.value=null
  saveDB()
}

onMounted(()=> dataSource.fetchAll())
</script>

<style scoped>
<style scoped>
/* ===== 主題變數（與其它頁一致） ===== */
:root{
  --bg:#f6faf8;
  --card:#fff;
  --text:#000;          /* 統一黑字 */
  --muted:#2f3a48;      /* 次要字也偏黑，對比佳 */
  --line:#e5e7eb;

  --primary:#28c7a5;
  --primary-weak:#e6fbf6;
  --blue:#2563eb;
  --blue-weak:#e8f0ff;

  --shadow:0 8px 24px rgba(15,23,42,.08);
  --radius-lg:16px;
  --radius-md:12px;
}

/* 全域：黑字 + 反鋸齒 */
section, section *{ color:var(--text) !important; -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale; }
::placeholder{ color:#333 !important; }

/* ===== 標題與工具列 ===== */
.section-title{ font-size:20px; font-weight:800; margin:6px 16px 10px; }
.toolbar{
  display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin:0 16px 12px;
  background:var(--card); border-radius:var(--radius-lg); padding:12px 14px; box-shadow:var(--shadow);
}
.row{ display:flex; gap:8px; align-items:center; }
.spacer{ flex:1; }
.muted{ color:var(--muted) !important; }
.small{ font-size:12px; }

/* 控件 */
.input, select, .btn{
  border:1px solid var(--line); background:#fff; border-radius:10px;
  height:34px; padding:0 10px; font-size:14px; max-width:100%;
}
.input.sm{ height:30px; padding:0 8px; }
.btn{ font-weight:800; color:#000 !important; box-shadow:0 4px 12px rgba(40,199,165,.15); }
.btn.ghost{ background:#fff; box-shadow:none; }
.btn.sm{ height:30px; padding:0 10px; }
.file-btn{ position:relative; overflow:hidden; }
.file-btn input{ position:absolute; inset:0; opacity:0; cursor:pointer; }

/* ===== 今日摘要 ===== */
.summary{
  display:flex; gap:16px; align-items:center; margin:8px 16px 12px;
  color:var(--muted) !important;
}
.summary b{ color:#000; }

/* ===== 主卡片與表格 ===== */
.card{
  background:var(--card); border-radius:var(--radius-lg); border:1px solid var(--line);
  margin:0 16px; overflow:hidden; box-shadow:var(--shadow);
}
.table{ width:100%; border-collapse:separate; border-spacing:0; }
.table thead th{
  background:#f8fafc; font-weight:800; text-align:left; padding:12px;
  border-bottom:1px solid var(--line);
}
.table tbody td{ padding:12px; border-bottom:1px solid #eef2f6; }
.table tbody tr:nth-child(even){ background:#fcfdff; }
.table tr.active{ outline:2px solid #bfdbfe; background:#eef4ff; }

/* 狀態章（語意一致） */
.badge{ display:inline-block; padding:.2rem .6rem; border-radius:999px; font-size:.85rem; font-weight:800; border:1px solid transparent; }
.badge-ok   { background:#ecfdf5; border-color:#a7f3d0; }
.badge-info { background:#eff6ff; border-color:#bfdbfe; }
.badge-warn { background:#fffbeb; border-color:#fde68a; }

/* ===== 詳情區塊 ===== */
.detail{ border-top:1px dashed var(--line); }
.detail-head{
  display:flex; justify-content:space-between; gap:10px;
  padding:10px 14px; border-bottom:1px dashed var(--line);
}
.detail-meta{ padding:12px 14px; }
.meta-title{ font-weight:900; margin-bottom:6px; }
.detail-note{ padding:12px 14px; }

/* slim 表格（詳情內） */
.table.slim .th, .table.slim .tr{ display:flex; align-items:center; gap:8px; }
.table.slim .th{
  font-weight:800; padding:10px 14px; border-bottom:1px solid #eef2f6; background:#f8fafc;
}
.table.slim .tr{ padding:10px 14px; border-bottom:1px solid #f3f6fb; }
.w100{ width:100px } .w120{ width:120px } .w160{ width:160px }
.center{ text-align:center }

/* ===== 抽屜（編輯器） ===== */
.drawer{
  position:fixed; right:0; top:0; bottom:0; width:min(620px,100%); z-index:20;
  background:#fff; border-left:1px solid var(--line); box-shadow:-8px 0 24px rgba(15,23,42,.12);
  display:flex; flex-direction:column;
}
.drawer-head{
  display:flex; align-items:center; justify-content:space-between; gap:8px;
  padding:12px 16px; border-bottom:1px solid #eef2f6;
}
.h2{ font-size:18px; font-weight:900; }
.h3{ font-size:16px; font-weight:800; }
.drawer-body{ padding:12px 16px; overflow:auto; }
.form-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:10px; }
.form-grid .col-span-3{ grid-column:span 3; }

/* ===== RWD ===== */
@media (max-width: 840px){
  .toolbar{ padding:10px 12px; }
  .summary{ margin:8px 12px; }
  .card{ margin:0 12px; }
  .form-grid{ grid-template-columns:1fr; }
}
</style>

