<template>
  <section class="rep-page">
    <!-- 頁首 -->
    <header class="rep-header">
      <div class="title">報表中心（員工）</div>
      <div class="spacer"></div>
      <button class="btn ghost small" @click="exportCSV">匯出 CSV</button>
      <button class="btn ghost small" @click="exportJSON">匯出 JSON</button>
    </header>

    <!-- 篩選列 -->
    <div class="rep-toolbar card-lite">
      <div class="row gap">
        <label class="label">日期</label>
        <input type="date" class="input" v-model="from">
        <span class="muted">—</span>
        <input type="date" class="input" v-model="to">

        <div class="chips">
          <button class="chip" @click="setRange(7)">近 7 天</button>
          <button class="chip" @click="setRange(30)">近 30 天</button>
          <button class="chip" @click="setRange(90)">近 90 天</button>
        </div>

        <div class="spacer"></div>

        <!-- 顯示控制 -->
        <div class="seg">
          <button :class="['segbtn',mode==='top'&&'active']" @click="mode='top'">Top {{ topN }}</button>
          <button :class="['segbtn',mode==='all'&&'active']" @click="mode='all'">全部</button>
        </div>

        <button class="btn" @click="recalc">重新整理</button>
      </div>
    </div>

    <!-- 主內容 -->
    <div class="rep-grid">
      <div class="card">
        <div class="panel-head">
          <div class="h3">出貨品項占比（{{ scope.storeName }}）</div>
          <div class="spacer"></div>
        </div>

        <div class="chart-wrap">
          <!-- 圓餅圖 -->
          <div class="donut">
            <svg :width="size" :height="size" :viewBox="`0 0 ${size} ${size}`">
              <g :transform="`translate(${size/2},${size/2})`">
                <template v-for="(s,i) in slices" :key="i">
                  <path :d="arcPath(s.start,s.end,outerR,innerR)" :fill="colors[i%colors.length]" />
                </template>
              </g>
            </svg>
            <div class="donut-center">
              <div class="donut-num">{{ totalQty }}</div>
              <div class="donut-cap">總數量</div>
            </div>
          </div>

          <!-- 圖例（含進度條與占比） -->
          <div class="legend">
            <div class="lg" v-for="(row,i) in displayRows" :key="row.name">
              <span class="dot" :style="{background:colors[i%colors.length]}"></span>
              <div class="grow">
                <div class="lg-top">
                  <span class="name">{{ row.name }}</span>
                  <span class="muted unit">/ {{ row.unit }}</span>
                  <span class="qty">{{ row.qty }}</span>
                  <span class="ratio">{{ (row.ratio*100).toFixed(1) }}%</span>
                </div>
                <div class="bar">
                  <div class="bar-fill" :style="{ width: (row.ratio*100)+'%' }"></div>
                </div>
              </div>
            </div>
            <div v-if="!displayRows.length" class="muted center" style="padding:8px 0">沒有資料</div>
          </div>
        </div>
      </div>

      <div class="card table-wrap">
        <div class="panel-head"><div class="h3">明細</div></div>
        <table class="table">
          <thead>
            <tr><th>品名</th><th>單位</th><th class="tr">數量</th><th class="tr">占比</th></tr>
          </thead>
          <tbody>
            <tr v-for="row in displayRows" :key="row.name">
              <td>{{ row.name }}</td>
              <td>{{ row.unit }}</td>
              <td class="tr">{{ row.qty }}</td>
              <td class="tr">{{ (row.ratio*100).toFixed(1) }}%</td>
            </tr>
            <tr v-if="!displayRows.length"><td colspan="4" class="center muted">沒有資料</td></tr>
          </tbody>
          <tfoot v-if="displayRows.length">
            <tr><th>合計</th><th>—</th><th class="tr">{{ totalQty }}</th><th class="tr">100%</th></tr>
          </tfoot>
        </table>
      </div>
    </div>
  </section>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useScope } from '@/store/scope'

const scope = useScope()

/* ===== 日期 ===== */
const today = ()=> new Date().toISOString().slice(0,10)
const from = ref(today()), to = ref(today())
function setRange(days){
  const t=new Date(), f=new Date(); f.setDate(t.getDate()-days+1)
  from.value=f.toISOString().slice(0,10)
  to.value=t.toISOString().slice(0,10)
}

/* ===== 假資料（豐富品項） ===== */
function genFakeOrders(){
  const items = [
    {name:'新鮮雞腿',unit:'份'},{name:'雞胸',unit:'份'},{name:'去骨雞腿排',unit:'份'},
    {name:'豬骨高湯',unit:'桶'},{name:'大骨湯',unit:'桶'},{name:'牛骨高湯',unit:'桶'},
    {name:'梅花豬',unit:'公斤'},{name:'五花豬',unit:'公斤'},{name:'牛腱',unit:'公斤'},
    {name:'豬絞肉',unit:'公斤'},{name:'牛絞肉',unit:'公斤'},
    {name:'鮭魚切片',unit:'份'},{name:'鯛魚片',unit:'份'},{name:'小卷',unit:'斤'},
    {name:'草蝦',unit:'盒'},{name:'白蝦',unit:'盒'},
    {name:'高麗菜',unit:'顆'},{name:'青江菜',unit:'斤'},{name:'空心菜',unit:'斤'},
    {name:'花椰菜',unit:'顆'},{name:'胡蘿蔔',unit:'斤'},{name:'馬鈴薯',unit:'斤'},
    {name:'洋蔥',unit:'斤'},{name:'大蒜',unit:'斤'},{name:'青蔥',unit:'斤'},
    {name:'香菜',unit:'把'},{name:'辣椒',unit:'斤'},{name:'番茄',unit:'斤'},
    {name:'香菇',unit:'斤'},{name:'金針菇',unit:'斤'},
    {name:'白米',unit:'包'},{name:'米漿醬油',unit:'瓶'},{name:'蠔油',unit:'瓶'},
    {name:'胡椒粉',unit:'罐'},{name:'鹽',unit:'包'},{name:'砂糖',unit:'包'},
    {name:'味醂',unit:'瓶'},{name:'米酒',unit:'瓶'},{name:'花生油',unit:'桶'},
    {name:'芝麻油',unit:'瓶'},{name:'奶油',unit:'塊'},
    {name:'雞蛋',unit:'盒'},{name:'牛奶',unit:'瓶'},{name:'起司片',unit:'包'},
    {name:'義大利麵',unit:'包'},{name:'米粉',unit:'包'},{name:'烏龍麵',unit:'包'}
  ]
  const storeId = scope.storeId
  const today = new Date()
  const list = []
  const daysBack = 45
  for(let d=0; d<daysBack; d++){
    const dt = new Date(today); dt.setDate(today.getDate()-d)
    const ds = dt.toISOString().slice(0,10)
    const pickCount = Math.floor(Math.random()*6)+5 // 5~10
    const picked = new Set()
    while(picked.size<pickCount) picked.add(Math.floor(Math.random()*items.length))
    const order = { id:`fake-${ds}-${d}`, date:ds, storeId, items:[] }
    for(const idx of picked){
      const it = items[idx]
      order.items.push({ name:it.name, unit:it.unit, qty: Math.floor(Math.random()*78)+3 })
    }
    list.push(order)
  }
  localStorage.setItem(`emp-orders-${storeId}`, JSON.stringify({ ord:list }))
  return list
}

/* ===== 取資料 ===== */
function safeParse(raw, fallback){ try{ return JSON.parse(raw) }catch{ return fallback } }
function getOrders(){
  const raw = localStorage.getItem(`emp-orders-${scope.storeId}`)
  if (!raw) return genFakeOrders()
  const obj = safeParse(raw, { ord:[] })
  if (!obj.ord?.length) return genFakeOrders()
  return (obj.ord || []).filter(o => o.storeId === scope.storeId)
}

/* ===== 彙總 ===== */
const rows = ref([]) // [{name,unit,qty}]
function recalc(){
  const list = getOrders().filter(o => o.date >= from.value && o.date <= to.value)
  const map = new Map()
  list.forEach(o => o.items.forEach(it=>{
    const k = it.name + '|' + it.unit
    map.set(k, (map.get(k)||0) + (+it.qty||0))
  }))
  rows.value = Array.from(map.entries())
    .map(([k,qty])=>{ const [name,unit] = k.split('|'); return { name, unit, qty } })
    .sort((a,b)=> b.qty - a.qty)
}
const totalQty = computed(()=> rows.value.reduce((s,r)=>s+(+r.qty||0),0))

/* ===== 顯示集合：Top N + 其他 ===== */
const mode = ref('top')  // 'top' | 'all'
const topN = ref(8)
const displayRows = computed(()=>{
  const total = totalQty.value || 1
  if (mode.value==='all') {
    return rows.value.map(r=>({ ...r, ratio: (+r.qty||0)/total }))
  }
  if (rows.value.length<=topN.value){
    return rows.value.map(r=>({ ...r, ratio: (+r.qty||0)/total }))
  }
  const top = rows.value.slice(0, topN.value)
  const restQty = rows.value.slice(topN.value).reduce((s,r)=>s+(+r.qty||0),0)
  const merged = [...top, { name:'其他', unit:'—', qty:restQty }]
  return merged.map(r=>({ ...r, ratio: (+r.qty||0)/total }))
})

/* ===== 圓餅（依 displayRows） ===== */
const size=260, outerR=110, innerR=70
const colors = ['#60a5fa','#34d399','#fbbf24','#f87171','#a78bfa','#f472b6','#22d3ee','#93c5fd','#84cc16','#fca5a5','#c084fc']
const slices = computed(()=>{
  const sum = displayRows.value.reduce((s,r)=>s+(+r.qty||0),0) || 1
  let acc = -Math.PI/2
  return displayRows.value.map(r=>{
    const a = (+r.qty||0)/sum * Math.PI*2
    const s = acc, e = acc + a; acc=e
    return { start:s, end:e }
  })
})
function arcPath(start, end, R, r){
  const large = end - start > Math.PI ? 1 : 0
  const sx = Math.cos(start)*R, sy = Math.sin(start)*R
  const ex = Math.cos(end)*R,   ey = Math.sin(end)*R
  const isx = Math.cos(end)*r,  isy = Math.sin(end)*r
  const iex = Math.cos(start)*r, iey = Math.sin(start)*r
  return `M ${sx} ${sy} A ${R} ${R} 0 ${large} 1 ${ex} ${ey} L ${isx} ${isy} A ${r} ${r} 0 ${large} 0 ${iex} ${iey} Z`
}

/* ===== 匯出 ===== */
function exportCSV(){
  const header = '品名,單位,數量,占比\n'
  const lines = displayRows.value.map(r => `${r.name},${r.unit},${r.qty},${(r.ratio*100).toFixed(1)}%`).join('\n')
  const meta  = `日期區間：${from.value}~${to.value}\n模式：${mode.value==='top'?'Top '+topN.value:'全部'}\n\n`
  const blob = new Blob([meta + header + lines], { type:'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href=url; a.download=`report-${scope.storeId}.csv`; a.click()
  URL.revokeObjectURL(url)
}
function exportJSON(){
  const payload = { from:from.value, to:to.value, mode:mode.value, topN:topN.value, rows:displayRows.value }
  const blob = new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a'); a.href=url; a.download=`report-${scope.storeId}.json`; a.click()
  URL.revokeObjectURL(url)
}

/* ===== 初始 ===== */
onMounted(()=>{ setRange(30); recalc() })
</script>

<style scoped>
/* ===== 主題變數：與前兩頁一致 ===== */
:root{
  --bg:#f6faf8;
  --card:#fff;
  --text:#000;          /* 全站黑字 */
  --muted:#2f3a48;      /* 次要字也偏黑，對比好 */
  --line:#e5e7eb;

  --primary:#28c7a5;
  --primary-weak:#e6fbf6;
  --blue:#2563eb;
  --blue-weak:#e8f0ff;

  --shadow:0 8px 24px rgba(15,23,42,.08);
  --radius-lg:16px;
  --radius-md:12px;
}

/* 全域：黑字 + 反鋸齒 */
.rep-page, .rep-page *{
  color:var(--text) !important;
  -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;
}
::placeholder{ color:#333 !important; }

/* 背景與容器 */
.rep-page{ padding:16px; background:var(--bg); min-height:100%; }
.spacer{ flex:1; }

/* ===== 頁首 ===== */
.rep-header{
  display:flex; align-items:center; gap:10px; margin-bottom:12px;
  background:var(--card); border-radius:var(--radius-lg); padding:14px 16px; box-shadow:var(--shadow);
}
.title{ font-size:20px; font-weight:800; }

/* ===== 控件/按鈕 ===== */
.input, .chip, .segbtn, .btn{
  border:1px solid var(--line); background:#fff; border-radius:10px;
  height:34px; padding:0 12px; font-size:14px; display:inline-flex; align-items:center; gap:6px;
}
.btn{ font-weight:800; color:#000 !important; }
.btn.ghost{ background:#fff; }
.btn:hover{ box-shadow:0 4px 14px rgba(40,199,165,.18); border-color:#d1fae5; }
.btn.primary{ background:var(--primary); }

.input{ height:34px; padding:0 10px; }
.label{ color:var(--muted) !important; }

/* chip / seg */
.chips{ display:flex; gap:8px; flex-wrap:wrap; }
.chip{ height:30px; padding:0 12px; cursor:pointer; font-weight:700; }
.chip:hover{ background:var(--primary-weak); border-color:#bff3e7; }

.seg{ display:flex; gap:8px; }
.segbtn{ height:30px; padding:0 12px; cursor:pointer; font-weight:700; border-radius:999px; }
.segbtn.active{ background:var(--blue-weak); border-color:#bfdbfe; }

/* ===== 卡片與工具列 ===== */
.card, .card-lite{
  background:var(--card); border-radius:var(--radius-lg); box-shadow:var(--shadow); padding:14px; min-width:0;
}
.card-lite{ border:1px dashed var(--line); box-shadow:none; }

.row{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
.gap{ gap:10px; }
.muted{ color:var(--muted) !important; }

/* ===== 主區塊網格 ===== */
.rep-grid{ display:grid; grid-template-columns:1.15fr 1fr; gap:14px; }
.panel-head{ display:flex; align-items:center; gap:8px; margin-bottom:8px; }
.h3{ font-weight:800; }

/* ===== 圓餅與圖例 ===== */
.chart-wrap{ display:flex; gap:18px; align-items:stretch; }
.donut{ position:relative; width:260px; height:260px; display:flex; align-items:center; justify-content:center; }
.donut svg{ width:100%; height:100%; display:block; }
.donut-center{
  position:absolute; text-align:center; background:#ffffffcc; backdrop-filter: blur(2px);
  padding:8px 10px; border:1px solid var(--line); border-radius:12px;
}
.donut-num{ font-size:22px; font-weight:900; line-height:1.1 }
.donut-cap{ font-size:12px; color:#334155 !important; }

.legend{
  flex:1; min-width:260px; max-height:280px; overflow:auto;
  display:flex; flex-direction:column; gap:10px; align-self:center; padding-right:6px;
}
.lg{ display:flex; gap:10px; align-items:flex-start; }
.dot{ width:12px; height:12px; border-radius:3px; margin-top:6px; box-shadow: inset 0 0 0 1px #0002; }
.grow{ flex:1; min-width:0; }
.lg-top{ display:flex; align-items:center; gap:8px; }
.name{ font-weight:800; }
.unit{ font-size:12px; color:#475569 !important; }
.qty{ margin-left:auto; font-weight:800; }
.ratio{ width:56px; text-align:right; color:#1f2937 !important; }

.bar{ height:8px; border-radius:999px; background:#eef2f6; overflow:hidden; margin-top:6px; }
.bar-fill{ height:100%; background:linear-gradient(90deg,#93c5fd,#60a5fa); }

/* ===== 表格 ===== */
.table-wrap{ overflow:auto; }
.table{
  width:100%; border-collapse:separate; border-spacing:0; min-width:560px;
  border:1px solid var(--line); border-radius:12px; overflow:hidden;
}
.table thead th{
  background:#f8fafc; font-weight:800; text-align:left; padding:12px;
  border-bottom:1px solid var(--line);
}
.table tbody td{ padding:12px; border-bottom:1px solid #eef2f6; }
.table tbody tr:nth-child(even){ background:#fcfdff; } /* 斑馬紋 */
.table .tr{ text-align:right; }
.center{ text-align:center; }

/* ===== 滾動條 ===== */
.legend::-webkit-scrollbar{ width:10px; }
.legend::-webkit-scrollbar-thumb{
  background:#e5e7eb; border-radius:999px; border:2px solid transparent; background-clip:content-box;
}

/* ===== RWD ===== */
@media (max-width:1024px){
  .rep-grid{ grid-template-columns:1fr; }
  .chart-wrap{ flex-direction:column; align-items:center; }
  .legend{ width:100%; max-height:none; }
}
</style>
