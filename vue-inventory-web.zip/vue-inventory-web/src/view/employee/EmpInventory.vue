<template>
  <section>
    <!-- 頁首工具列 -->
    <div class="main-head">
      <div class="h2">門市庫存</div>
      <div class="spacer"></div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <input class="input sm" v-model.trim="q" placeholder="搜尋名稱或代碼…">
        <select class="input sm" v-model="status">
          <option value="">全部狀態</option>
          <option value="available">可用</option>
          <option value="low">缺貨</option>
          <option value="disabled">停售</option>
        </select>
        <select class="input sm" v-model="sortBy" title="排序">
          <option value="name">名稱</option>
          <option value="code">代碼</option>
          <option value="qty">數量</option>
          <option value="status">狀態</option>
        </select>
        <button class="btn ghost small" @click="asc = !asc">{{ asc ? '▲ 升冪' : '▼ 降冪' }}</button>
        <button class="btn ghost small" @click="exportJSON">匯出</button>
        <label class="btn ghost small file-btn" v-can="'inventory.edit'">
          匯入 <input type="file" accept="application/json" @change="importJSON">
        </label>
      </div>
    </div>

    <div class="two-col">
      <!-- 左欄 -->
      <aside class="side" :class="{open:drawerOpen}">
        <div class="side-head">
          <div class="muted small">店面：{{ scope.storeName }}</div>
          <div class="chips" style="margin-top:8px">
            <button v-for="t in tags" :key="t.id" class="chip" :class="{on:selTags.has(t.id)}" @click="toggleTag(t.id)">#{{ t.name }}</button>
          </div>
          <div class="only-mobile" style="margin-top:8px">
            <button class="btn w100" v-can="'inventory.edit'" @click="createQuick()">＋ 新增品項</button>
          </div>
        </div>

        <div class="side-list">
          <div class="side-item" v-for="it in filteredSorted" :key="it.id" :class="{active: it.id===selectedId}" @click="select(it.id)">
            <div class="thumb sm" :style="{ backgroundImage: `url(${it.image||placeholder})` }"></div>
            <div class="grow">
              <div style="font-weight:700">{{ it.name }}</div>
              <div class="muted small">
                代碼：{{ it.code || '—' }}｜數量：{{ it.qty ?? 0 }} {{ it.unit || '' }}
              </div>
              <div class="muted small">
                狀態：
                <span :class="['pill', pillClass(it.status)]">{{ sText(it.status) }}</span>
                ｜安全庫存：{{ it.safeStock ?? '—' }}
              </div>
            </div>
          </div>
          <p v-if="!filteredSorted.length" class="muted center">沒有符合的品項</p>
        </div>
      </aside>

      <transition name="fade"><div v-if="drawerOpen" class="backdrop" @click="drawerOpen=false"></div></transition>

      <!-- 右欄 -->
      <main class="card">
        <div class="main-head">
          <button class="icon-btn only-mobile" @click="drawerOpen=true">☰</button>
          <div class="h2">{{ cur ? '食材詳情' : '請從左側選取食材' }}</div>
          <div class="spacer"></div>
          <div style="display:flex;gap:8px" v-if="cur">
            <button class="btn" v-can="'inventory.edit'" @click="duplicate()">複製</button>
            <button class="btn danger" v-can="'inventory.edit'" @click="removeOne()">刪除</button>
            <button class="btn primary" v-can="'inventory.edit'" @click="save()">儲存</button>
          </div>
          <div v-else>
            <button class="btn primary" v-can="'inventory.edit'" @click="createQuick()">＋ 新增品項</button>
          </div>
        </div>

        <div v-if="!cur" class="center muted" style="padding:24px">
          📦 可從左側搜尋並點選品項
        </div>

        <div v-else class="detail-grid">
          <!-- 圖片 -->
          <div>
            <div class="thumb" :style="{ backgroundImage: `url(${edit.image||placeholder})` }"></div>
            <label class="btn ghost small" style="margin-top:8px" v-can="'inventory.edit'">
              上傳圖片 <input type="file" accept="image/*" @change="pickImage">
            </label>
            <button class="btn ghost small" v-if="edit.image" v-can="'inventory.edit'" @click="edit.image=''">移除圖片</button>
            <div style="margin-top:8px">
              <button class="btn ghost small" v-can="'inventory.edit'" @click="toggleDisable()">
                {{ edit.status==='disabled' ? '恢復銷售' : '一鍵停售' }}
              </button>
            </div>
          </div>

          <!-- 表單 -->
          <div>
            <div class="tr">
              <label class="muted" style="min-width:72px">名稱</label>
              <input class="input w100" v-model.trim="edit.name" :readonly="!canEdit" placeholder="食材名稱">
            </div>
            <div class="tr">
              <label class="muted" style="min-width:72px">代碼</label>
              <input class="input w100" v-model.trim="edit.code" :readonly="!canEdit" placeholder="條碼/自訂代碼">
            </div>

            <div class="tr" style="align-items:center">
              <label class="muted" style="min-width:72px">單位</label>
              <input class="input w120" v-model.trim="edit.unit" :readonly="!canEdit" placeholder="份、公斤…">
              <label class="muted" style="min-width:72px">安全庫存</label>
              <input class="input w120" type="number" min="0" v-model.number="edit.safeStock" :readonly="!canEdit" @change="autoStatus()">
            </div>

            <div class="tr" style="align-items:center">
              <label class="muted" style="min-width:72px">在庫數量</label>
              <input class="input w120" type="number" min="0" v-model.number="edit.qty" :readonly="!canEdit" @change="autoStatus()">
              <div v-if="canEdit" style="display:flex;gap:6px;flex-wrap:wrap">
                <button class="btn small" @click="adjust(-10)">-10</button>
                <button class="btn small" @click="adjust(-1)">-1</button>
                <input class="input w80" type="number" v-model.number="adj" placeholder="±N">
                <button class="btn small" @click="applyAdj()">套用</button>
                <button class="btn small" @click="adjust(1)">+1</button>
                <button class="btn small" @click="adjust(10)">+10</button>
              </div>
            </div>

            <div class="tr" style="align-items:center">
              <label class="muted" style="min-width:72px">狀態</label>
              <button class="state-btn" :class="edit.status" @click="cycle()" :disabled="!canEdit">{{ sText(edit.status) }}</button>
              <span class="muted small">（會隨數量與安全庫存自動更新）</span>
            </div>

            <div class="tr" style="align-items:flex-start; padding-bottom:0;">
              <label class="muted" style="min-width:72px">標籤</label>
              <div class="w100">
                <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px">
                  <span v-for="tid in edit.tags" :key="tid" class="tagchip">
                    #{{ tagName(tid) }}
                    <button class="icon-btn" v-if="canEdit" @click="removeTag(tid)">✕</button>
                  </span>
                  <span v-if="!edit.tags.length" class="muted">尚未指定標籤</span>
                </div>
                <div v-if="canEdit" style="display:flex;gap:8px">
                  <select v-model="tagToAdd" class="input w200">
                    <option disabled value="">選擇標籤</option>
                    <option v-for="t in tags" :key="t.id" :value="t.id">#{{ t.name }}</option>
                  </select>
                  <button class="btn small" :disabled="!tagToAdd" @click="addTag()">加入</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>

    <transition name="fade"><div v-if="toast" class="toast">{{ toast }}</div></transition>
  </section>
</template>

<script setup>
import { reactive, ref, computed, onMounted } from 'vue'
import { useScope } from '@/store/scope'
import { usePerm } from '@/store/perm'

const scope = useScope()
const { ensureLoaded, can } = usePerm(); ensureLoaded()
const canEdit = computed(()=> can('inventory.edit'))

const rid = ()=> 'id-' + Math.random().toString(36).slice(2,10)
const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200">
    <rect width="100%" height="100%" fill="#eef2ff"/>
    <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
      fill="#94a3b8" font-family="sans-serif" font-size="14">No Image</text></svg>`)

const drawerOpen = ref(false)
const q = ref(''); const status = ref('')
const sortBy = ref('name'); const asc = ref(true)
const selTags = reactive(new Set())
const tagToAdd = ref('')
const toast = ref(''); const tip = (m)=>{ toast.value=m; setTimeout(()=>toast.value='',1200) }
const sText = s => s==='available'?'可用': s==='low'?'缺貨':'停售'
const pillClass = s => s==='available'?'pill-ok': s==='low'?'pill-warn':'pill-off'
const tagName = id => tags.value.find(t=>t.id===id)?.name ?? '（已刪除）'

/* 資料管理 */
const DB_KEY = computed(()=>`emp-inv-${scope.storeId}`)
const db = reactive({ _version:1, items:[], tags:[] })
function saveDB(){ localStorage.setItem(DB_KEY.value, JSON.stringify(db)) }
function loadDB(){
  const raw = localStorage.getItem(DB_KEY.value)
  if (raw){
    try{
      const obj = JSON.parse(raw)
      if (!obj._version) obj._version = 0
      if (obj._version === 0){
        obj.items = (obj.items||[]).map(x=>({ qty:0, ...x }))
        obj._version = 1
      }
      Object.assign(db, obj); return
    }catch{ localStorage.removeItem(DB_KEY.value) }
  }
  db.tags = [{id:rid(),name:'生鮮'},{id:rid(),name:'冷凍'},{id:rid(),name:'蔬菜'}]
  db.items = [
    { id:rid(), name:'新鮮雞腿', code:'CK-001', unit:'份', safeStock:10, qty:30, status:'available', tags:[db.tags[0].id], image:'' },
    { id:rid(), name:'新鮮豬腿', code:'PK-002', unit:'公斤', safeStock:8,  qty:2,  status:'low',       tags:[db.tags[0].id], image:'' },
    { id:rid(), name:'高麗菜',   code:'VE-010', unit:'顆', safeStock:6,  qty:12, status:'available', tags:[db.tags[2].id], image:'' },
  ]
  saveDB()
}
const tags = computed(()=> db.tags)

const filtered = computed(()=>{
  const kw = q.value.trim()
  return db.items
    .filter(it => !status.value || it.status===status.value)
    .filter(it => !selTags.size || it.tags.some(tid=>selTags.has(tid)))
    .filter(it => !kw || it.name.includes(kw) || (it.code||'').includes(kw))
})
const filteredSorted = computed(()=>{
  const list = [...filtered.value]
  list.sort((a,b)=>{
    let av, bv
    if (sortBy.value==='name'){ av=a.name||''; bv=b.name||'' }
    else if (sortBy.value==='code'){ av=a.code||''; bv=b.code||'' }
    else if (sortBy.value==='qty'){ av=a.qty||0; bv=b.qty||0 }
    else { av=a.status||''; bv=b.status||'' }
    if (av<bv) return asc.value?-1:1
    if (av>bv) return asc.value?1:-1
    return 0
  })
  return list
})

const selectedId = ref(null)
const cur = computed(()=> db.items.find(x=>x.id===selectedId.value) || null)
const edit = reactive({})
const adj = ref(0)

function select(id){
  selectedId.value = id
  const src = db.items.find(x=>x.id===id)
  if (src) Object.assign(edit, JSON.parse(JSON.stringify(src)))
  drawerOpen.value=false
}
function createQuick(){
  if (!canEdit.value) return
  const t = { id:rid(), name:'新食材', code:'', unit:'份', safeStock:0, qty:0, status:'available', tags:[], image:'' }
  db.items.unshift(t); saveDB(); select(t.id); tip('已新增品項')
}
function cycle(){
  if (!canEdit.value) return
  edit.status = edit.status==='available'?'low': edit.status==='low'?'disabled':'available'
}
function toggleDisable(){
  if (!canEdit.value) return
  edit.status = edit.status==='disabled' ? 'available' : 'disabled'
}
function autoStatus(){
  if (edit.status==='disabled') return
  const low = Number(edit.safeStock||0)
  const q = Number(edit.qty||0)
  edit.status = q < low ? 'low' : 'available'
}
function adjust(n){
  if (!canEdit.value) return
  edit.qty = Math.max(0, Number(edit.qty||0) + n)
  autoStatus()
}
function applyAdj(){
  if (!canEdit.value) return
  const n = Number(adj.value||0)
  if (!n) return
  adjust(n); adj.value = 0
}
function addTag(){
  if (!canEdit.value || !tagToAdd.value) return
  if (!edit.tags.includes(tagToAdd.value)) edit.tags.push(tagToAdd.value)
  tagToAdd.value=''
}
function removeTag(id){
  if (!canEdit.value) return
  edit.tags = edit.tags.filter(x=>x!==id)
}
function duplicate(){
  if (!canEdit.value || !cur.value) return
  const copy = JSON.parse(JSON.stringify(edit)); copy.id = rid(); copy.name += '（複製）'
  db.items.unshift(copy); saveDB(); select(copy.id); tip('已複製')
}
function removeOne(){
  if (!canEdit.value || !cur.value) return
  if (!confirm(`刪除「${cur.value.name}」？`)) return
  db.items = db.items.filter(x=>x.id!==cur.value.id)
  saveDB(); selectedId.value=null; Object.keys(edit).forEach(k=>delete edit[k]); tip('已刪除')
}
function save(){
  if (!canEdit.value) return
  if (!edit.name?.trim()) return tip('請輸入名稱')
  autoStatus()
  const i = db.items.findIndex(x=>x.id===edit.id)
  if (i>=0) db.items[i] = JSON.parse(JSON.stringify(edit))
  saveDB(); tip('已儲存')
}

function toggleTag(id){ selTags.has(id) ? selTags.delete(id) : selTags.add(id) }
function pickImage(e){
  const f = e.target.files?.[0]; if(!f) return
  const fr = new FileReader(); fr.onload=()=>{ edit.image=String(fr.result) }; fr.readAsDataURL(f)
}

function exportJSON(){
  const blob = new Blob([JSON.stringify(db,null,2)], { type:'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${DB_KEY.value}.json`
  a.click()
  URL.revokeObjectURL(url)
}
function importJSON(e){
  if (!canEdit.value) return
  const f = e.target.files?.[0]; if(!f) return
  const r = new FileReader()
  r.onload = ()=>{
    try{
      const obj = JSON.parse(String(r.result))
      if (!obj || !Array.isArray(obj.items) || !Array.isArray(obj.tags)) throw new Error()
      // 相容舊檔，補齊必要欄位
      obj.items = obj.items.map(x=>({
        qty:0, safeStock:0, status:'available', tags:[], image:'', unit:'', code:'', ...x
      }))
      db.items = obj.items
      db.tags  = obj.tags
      db._version = 1
      saveDB()
      tip('已匯入')
    }catch{
      tip('匯入失敗：格式錯誤')
    }
  }
  r.readAsText(f,'utf-8')
}

onMounted(()=> loadDB())
</script>

<style scoped>
/* ===== 基礎主題：薄荷綠 / 清爽灰 ===== */
:root {
  --bg: #f6faf8;
  --card: #ffffff;
  --text: #0f172a;
  --muted: #64748b;

  --primary: #28c7a5;      /* 薄荷綠主色 */
  --primary-weak: #e6fbf6;
  --warn: #f59e0b;
  --ok: #10b981;
  --off: #a1a1aa;

  --line: #e5e7eb;
  --chip: #eef2ff;
  --chip-on: #dbeafe;

  --shadow: 0 8px 24px rgba(15, 23, 42, .08);
  --radius-lg: 16px;
  --radius-md: 12px;
  --radius-sm: 10px;
}

*, *::before, *::after { box-sizing: border-box; }
section { color: var(--text); }
section { background: var(--bg); padding: 12px; }

/* ===== 主列工具列 ===== */
.main-head {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px 18px;
  margin-bottom: 12px;
  background: var(--card);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow);
}
.h2 { font-size: 18px; font-weight: 800; }
.spacer { flex: 1; }

.input, select, button, .state-btn {
  height: 34px;
  border: 1px solid var(--line);
  background: #fff;
  border-radius: 10px;
  padding: 0 10px;
  font-size: 14px;
}
.input.sm { height: 30px; }
.input.w100 { width: 100%; }
.input.w120 { width: 120px; }
.input.w80  { width: 80px; }
.input.w200 { width: 200px; }

button.btn {
  background: var(--primary);
  color: #fff;
  border: none;
  border-radius: 12px;
  padding: 0 14px;
  height: 34px;
  font-weight: 700;
  box-shadow: 0 4px 14px rgba(40,199,165,.25);
  transition: transform .05s ease, filter .15s ease;
}
button.btn:hover { filter: brightness(1.03); }
button.btn:active { transform: translateY(1px); }
button.btn.primary { background: var(--primary); }
button.btn.danger  { background: #ef4444; box-shadow: 0 4px 14px rgba(239,68,68,.20); }
button.btn.ghost {
  background: #fff;
  color: var(--text);
  border: 1px solid var(--line);
  box-shadow: none;
}
button.small { height: 30px; padding: 0 10px; }
button.w100 { width: 100%; }
.icon-btn {
  background: #fff; border: 1px solid var(--line); border-radius: 10px;
  width: 34px; height: 34px; display: grid; place-items: center;
}

/* 匯入檔案按鈕 */
.file-btn { position: relative; overflow: hidden; }
.file-btn input[type="file"]{ position:absolute; inset:0; opacity:0; cursor:pointer; }

/* ===== 版面：左側清單 + 右側卡片 ===== */
.two-col {
  display: grid;
  grid-template-columns: 320px 1fr;
  gap: 12px;
}
.side, main.card {
  background: var(--card);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow);
  overflow: hidden;
}

/* 右側主卡 */
main.card {
  width: 100%;
  padding: 22px;
  min-width: 0;
}

/* 左側欄（具備行動裝置抽屜效果） */
.side { display: grid; grid-template-rows: auto 1fr; }
.side-head {
  padding: 14px 14px 8px 14px;
  border-bottom: 1px solid var(--line);
  position: sticky; top: 0; background: var(--card); z-index: 1;
}
.side-list { padding: 8px; overflow: auto; }

/* 清單項目卡片化 */
.side-item {
  display: grid;
  grid-template-columns: 54px 1fr;
  gap: 10px;
  align-items: center;
  padding: 10px;
  margin: 6px 0;
  background: #fff;
  border: 1px solid var(--line);
  border-radius: var(--radius-md);
  transition: box-shadow .15s ease, transform .03s ease, border-color .15s ease;
  cursor: pointer;
}
.side-item:hover { border-color: #dbeafe; box-shadow: 0 6px 16px rgba(30, 64, 175, .08); }
.side-item.active { outline: 2px solid #bfdbfe; box-shadow: 0 8px 18px rgba(30, 64, 175, .12); }
.thumb { background-size: cover; background-position: center; border-radius: 12px; }
.thumb.sm { width: 54px; height: 54px; }
.thumb:not(.sm) { width: 180px; height: 135px; border-radius: 14px; }

/* 小字/提示 */
.muted { color: var(--muted); }
.small { font-size: 12px; }
.center { text-align: center; }

/* 標籤 chips */
.chips { display:flex; flex-wrap:wrap; gap:8px; }
.chip {
  background: var(--chip);
  border: 1px solid #e2e8f0;
  color: #334155;
  padding: 6px 10px;
  border-radius: 999px;
  font-size: 12px;
}
.chip.on { background: var(--chip-on); border-color: #bfdbfe; color: #1e40af; font-weight: 700; }

/* 狀態膠囊（列表用） */
.pill {
  display:inline-flex; align-items:center; gap:6px;
  padding: 2px 8px; border-radius: 999px; font-size: 12px; font-weight: 700;
}
.pill-ok   { background:#ecfdf5; color:#065f46; border:1px solid #a7f3d0; }
.pill-warn { background:#fffbeb; color:#92400e; border:1px solid #fde68a; }
.pill-off  { background:#f4f4f5; color:#3f3f46; border:1px solid #e4e4e7; }

/* 詳情區的狀態切換按鈕 */
.state-btn {
  min-width: 100px;
  border-radius: 999px;
  font-weight: 800;
}
.state-btn.available { background:#ecfdf5; color:#065f46; border:1px solid #a7f3d0; }
.state-btn.low        { background:#fffbeb; color:#92400e; border:1px solid #fde68a; }
.state-btn.disabled   { background:#f4f4f5; color:#3f3f46; border:1px solid #e4e4e7; }

/* 表單列 */
.tr { display: flex; flex-wrap: wrap; gap: 8px; padding: 10px 0; border-bottom: 1px dashed var(--line); }
.tr:last-child{ border-bottom: none; }

/* 標籤 chip（可移除） */
.tagchip{
  display:inline-flex; align-items:center; gap:6px;
  background:#f1f5f9; border:1px solid #e2e8f0; color:#334155;
  padding: 4px 10px; border-radius: 999px; font-size: 12px;
}

/* 右下吐司 */
.toast{
  position: fixed; right: 18px; bottom: 18px;
  background: #111827; color: #fff;
  padding: 10px 14px; border-radius: 12px;
  box-shadow: var(--shadow); opacity: .96;
}

/* 轉場 */
.fade-enter-active, .fade-leave-active { transition: opacity .18s ease; }
.fade-enter-from, .fade-leave-to { opacity: 0; }

/* === 行動裝置：抽屜 === */
.only-mobile { display: none; }
.backdrop { position: fixed; inset:0; background: rgba(2,6,23,.35); z-index: 8; }
.detail-grid { width:100%; max-width:100%; display:grid; grid-template-columns: 220px minmax(0, 1fr); gap: 20px; align-items:start; }

@media (max-width: 980px){
  .two-col { grid-template-columns: 1fr; }
  .only-mobile { display: block; }
  .side {
    position: fixed; z-index: 9; inset: 0 auto 0 0; width: 88%;
    transform: translateX(-100%); transition: transform .22s ease;
    box-shadow: var(--shadow);
  }
  .side.open { transform: translateX(0); }
  main.card { padding: 16px; }
}

/* 美化捲軸（可選） */
.side-list::-webkit-scrollbar{ width: 10px; }
.side-list::-webkit-scrollbar-thumb{
  background:#e5e7eb; border-radius: 999px; border:2px solid transparent; background-clip: content-box;
}
section, input, select, button, label, .muted, .small, .pill, .state-btn, .chip, .tagchip {
  color: #000 !important;
}

/* Placeholder 也同步變深 */
::placeholder {
  color: #333 !important;
}

/* 禁用、只讀狀態的輸入框也保持黑字 */
input:read-only,
input:disabled,
select:disabled {
  color: #000 !important;
}

/* 背景維持白底 */
main.card, .side, .main-head {
  background: #fff !important;
}
</style>
